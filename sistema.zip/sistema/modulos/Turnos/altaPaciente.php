<?php

require '../../php/conexion.php';

session_start();

// Si no existe la variable de sesión logueado, entonces el usuario debe loguearse.
if (!isset($_SESSION["logueado"])) {
  header("location: ../../..iniciar_sesion.php?error=debe_loguearse");
  exit;
}


$sql= "SELECT * FROM ocupacion ";

$rs_ocupacion= mysqli_query($conexion,$sql);

$sql= "SELECT * FROM obrasocial";

$rs_obrasocial=mysqli_query($conexion,$sql);



?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Nuevo paciente</title>
  <script src= "validar.js"></script>
</head>

  <div align="center">

    <font color="black" face="Verdana, Arial, Helvetica, sans-serif">



   <h1>Crear paciente</h1>

    <p>
      <a href="listado.php" style="color: black">Lista de pacientes</a> ||
      <a href="buscar_cliente.php" style="color: black">Buscar</a> 
    </p>
    <br>

    <form method="POST"  id="formulario" action="procesamiento/procesarAlta.php">

      <h3>Ingrese los datos del paciente</h3>
      <p>
        <label>Nombre*</span>
        <input type="text" id="nombre" name="nombre" maxlength="20"  >
        <span id="user"></span>
        </label>
      </p>
      <p>
        <label>Apellido* </span>
        <input type="text" id="apellido" name="apellido" maxlength="25">
        <span id="lastname"></span>

        </label>
      </p>
      <p>
        <label>DNI*</span>
        <input type="text" id="dni" name="dni" maxlength="10">
        <span id="document"></span>

        </label>
      </p>
      <p>
       <label>Fecha de Nacimiento*</span>
        <input type="date"  name="fechaNaci" placeholder="
        AAAA/MM/DD" >
        </label>
      </p>   
      <p>
       <label>Fecha de Ingreso*</span>
        <input type="date" name="fechaIn" placeholder="
        AAAA/MM/DD" value="<?php echo date("m/d/Y"); ?>">
        </label>
      </p> 
      <p>
         Ocupación <select name="cboOcupacion">
            <?php while ($row = $rs_ocupacion->fetch_assoc()): ?>
              <option value="<?php echo $row['id_ocupacion']; ?>">
                <?php echo $row["descripcion"]; ?>
                </option>
              <?php endwhile; ?>
          </select>
      </p>
      <p>
         Obra social <select name="cboObrasocial">
            <?php while ($row = $rs_obrasocial->fetch_assoc()): ?>
              <option value="<?php echo $row['id_obrasocial']; ?>">
                <?php echo $row["descripcion"]; ?>
                </option>
              <?php endwhile; ?>
          </select>
      </p>
      <p>
       <p id="mensajeError"></p> 
        <button type="button"  onclick="window.history.go(-1); return false;">Cancelar</button> &nbsp;
        <input type="button" value="Guardar">
      </p>
    </form>
    
  </div>

</body>
</html>