<?php

require ('../../php/conexion.php');

$id_provincia= $_GET['provincia'];


$sql= "SELECT * FROM ciudades "
. "WHERE id_provincia=".$id_provincia;

$rs= mysqli_query($conexion, $sql);

 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 </head>
 <body>
 	<?php while ($datoCiudad=mysqli_fetch_array($rs)) { ?>
 		<option value="<?php echo $datoCiudad['id_ciudad'] ?>"><?php echo $datoCiudad['descripcion'] ?></option>
 	<?php } ?>
 </body>
 </html>