<?php

require ('../../../php/conexion.php');

session_start();

if (!isset($_SESSION["logueado"])) {
	header("location:../../..iniciar_sesion.php?error=debe_loguearse");
	exit;
}

$persona_id = (int) trim($_GET['id_persona']);

$domicilio_id = (int)trim($_GET['id_domicilio']);

// MODIFICO PERSONA
$sql = "UPDATE domicilios SET estado=0 WHERE id_domicilio=" . $domicilio_id;


// si no puedo modificar, redirecciono al formulario con mensaje de error
if (!mysqli_query($conexion, $sql)) {
	$mensaje = 'DOMICILIO_ESTADO_UPDATE_ERROR';
	header("location: ../listado.php?id_persona=$persona_id&mensaje=$mensaje");
	exit;
}

$mensaje = 'DOMICILIO_ESTADO_UPDATE_OK';
header("location: ../listado.php?id_persona=$persona_id&mensaje=$mensaje");

?>