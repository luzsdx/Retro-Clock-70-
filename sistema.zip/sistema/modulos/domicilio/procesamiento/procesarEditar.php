<?php

require '../../../php/conexion.php';

session_start();

if (!isset($_SESSION["logueado"])) {
	header("location:../../..iniciar_sesion.php?error=debe_loguearse");
	exit;
}

$id_persona= $_POST["personaID"];

$id_domicilio= $_POST['domicilioID'];
$observacion=$_POST['observacion'];
$provincia= $_POST['cboProvincia'];
$ciudades=$_POST['cboCiudades']; 
$barrio=$_POST['barrio'];
$calle=$_POST['calle'];
$altura=$_POST['altura'];
$piso=$_POST['piso'];
$torre=$_POST['torre'];
$manzana=$_POST['manzana'];
$sectorparcela=$_POST['sector_parcela'];





$sql= "UPDATE domicilios SET observacion='$observacion', calle='$calle', barrio='$barrio', calle='$calle', altura='$altura', piso='$piso', torre='$torre', manzana='$manzana', sector_parcela='$sectorparcela', id_ciudad='$ciudades'"
    . "WHERE id_domicilio =". $id_domicilio;


if (!mysqli_query($conexion,$sql)) {
 $mensaje= "MODIFICAR_DOMICILIO_ERROR";
 header("location: ../listado.php?id_persona=$id_persona&mensaje=$mensaje");
 exit;   
}


$mensaje='MODIFICAR DOMICILIO OK';
header("location: ../listado.php?id_persona=$id_persona&mensaje=$mensaje")


?>