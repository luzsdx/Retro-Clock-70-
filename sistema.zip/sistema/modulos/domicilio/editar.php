<?php

require '../../php/conexion.php';

session_start();

// Si no existe la variable de sesión logueado, entonces el usuario debe loguearse.
if (!isset($_SESSION["logueado"])) {
	header("location: ../../iniciar_sesion.php?error=debe_loguearse");
	exit;
}

if (isset($_GET['mensaje'])) {
	switch ($_GET['mensaje']) {
		case 'MODIFICAR_DOMICILIO_ERROR':
			$mensaje = 'Ha ocurrido un error al intentar modificar el paciente.';
			break;

		case 'MODIFICAR_CIUDAD_ERROR':
			$mensaje = 'Ha ocurrido un error al intentar modificar la persona.';
			break;
	}
}

$id_persona = $_GET['id_persona'];
$id_domicilio= $_GET['id_domicilio'];

$sql= "SELECT * FROM provincia ";

$rs_provincia=mysqli_query($conexion,$sql);

//$sql="SELECT * FROM ciudades";

//$rs_ciudad=mysqli_query($conexion,$sql);


$sql=  "SELECT * FROM domicilios "
     ."INNER JOIN ciudades on domicilios.`id_ciudad`= ciudades.`id_ciudad` "
     ."WHERE domicilios.id_persona =". $id_persona." AND domicilios.id_domicilio=".$id_domicilio;


$rs_domicilios = mysqli_query($conexion, $sql);




?>

<!DOCTYPE html>
<html>
<head>
	<title>Domicilio</title>
</head>     
  
<body bgcolor="orange">
	<?php require '../../php/menu.php'; ?>
	<div align='center'>
		<h1><b>Modificar domicilio</b></h1>
      <script type="text/javascript" src="../../funciones/consultarCombos.js"></script>

    	<?php if (isset($mensaje)): ?>
    		<h3><font color="red"><?php echo $mensaje; ?></font></h3>
    	<?php endif; ?>
		<form method="POST" action="procesamiento/procesarEditar.php">
			<input type="hidden" name="personaID" value=' <?php echo $id_persona ?>' >
      <input type="hidden" name="domicilioID" value= '<?php echo $id_domicilio ?>'>
			<table border="1" cellpadding="2" cellspacing="0">
				<tbody>

     <?php while ($row= $rs_domicilios->fetch_assoc()): ?>

      <p>
        <label>Observación
        <input type="text" name="observacion" value="<?php echo utf8_encode($row['observacion']); ?>">
        </label>
      </p>
      <p>
        <label> Provincia</label>
        <select name="cboProvincia" onchange="consultarCiudades(this.value)" required="Debe rellenar el campo">
          <option value="0" >Sin especificar</option>
          <?php while ($datosProvincia=mysqli_fetch_array($rs_provincia)){ ?>
            <option value= "<?php echo $datosProvincia['id_provincia'] ?>"> <?php echo $datosProvincia['descripcion']; ?> 
             </option>
          <?php } ?>
        </select>
      </p>
      <p>
        <label> Ciudad</label>
        <select name="cboCiudades" id="ciudades" >
          <option value="0" >Sin especificar</option>

        </select>
      </p>
            <p>Barrio
        <input type="text"
        name="barrio" value="<?php echo utf8_encode($row['barrio']); ?>">
      </p>
      <p>Calle
        <input type="text" name="calle" value="<?php echo utf8_encode($row['calle']); ?>">
      </p>
      <p>Altura
        <input type="text" name="altura" value="<?php echo utf8_encode($row['altura']); ?>">
      </p>
      <p>Piso
        <input type="text" name="piso" value="<?php echo utf8_encode($row['piso']); ?>">
      </p>
      <p>Torre
        <input type="text" name="torre" value="<?php echo utf8_encode($row['torre']); ?>">
      </p>
      <p>Manzana
        <input type="text" name="manzana" value="<?php echo utf8_encode($row['manzana']); ?>">
      </p>
      <p>Sector/Parcela
        <input type="text" name="sector_parcela" value="<?php echo utf8_encode($row['sector_parcela']); ?>">
      </p>

      <p>
        <button type="button" onclick="window.history.go(-1); return false;">Cancelar</button> &nbsp;
        <input type="submit" value="Guardar">
      </p>


    </form>
    
  </div>
<?php endwhile;?>

</body>
</html>