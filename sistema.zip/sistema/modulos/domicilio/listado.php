<?php

require '../../php/conexion.php';

session_start();

// Si no existe la variable de sesión logueado, entonces el usuario debe loguearse.
if (!isset($_SESSION["logueado"])) {
	header("location: iniciar_sesion.php?error=debe_loguearse");
	exit;
}

if (isset($_GET['mensaje'])) {
	switch ($_GET['mensaje']) {
        case 'GUARDAR_DOMICILIO_OK':
            $mensaje = 'Domicilio agregado correctamente.';
            break;

		case 'GUARDAR_DOMICILIO_ERROR':
			$mensaje = 'Ha ocurrido un error al intentar crear el domicilio.';
			break;
	}
}

$id_persona= $_GET["id_persona"];

//$sql= "SELECT nombre, apellido FROM personas where id_persona = $id_persona";

//$rs_na=mysqli_query($conexion,$sql);

//$persona = mysqli_fetch_array($rs_na);

//$nombre = $persona['nombre']." ".$persona['apellido'];



$sql = "SELECT domicilios.id_domicilio, provincia.`descripcion` AS 'provincia', ciudades.`descripcion` AS 'ciudad' ,domicilios. id_domicilio,`observacion`,`barrio`,`calle`,`altura`,`piso`,`torre`,`manzana`,`sector_parcela` "
."FROM domicilios JOIN ciudades ON domicilios.`id_ciudad` = ciudades.`id_ciudad` "
."JOIN provincia ON provincia.`id_provincia` = ciudades.`id_ciudad` "
."WHERE domicilios.estado = 1 and domicilios.`id_persona` =".$id_persona;


//echo $sql;
//exit();


//descripcion contacto=  contacto
$rs = mysqli_query($conexion, $sql);
?>

<!DOCTYPE html>
<html>
<head>
	<title>Domicilios</title>
</head>
<body bgcolor="orange">
	<?php require '../../php/menu.php'; ?>
	<div align='center'>


		<h1><b>Listado de Domicilios</b></h1>

    	<?php if (isset($mensaje)): ?>
    		<h3><font color="red"><?php echo $mensaje; ?></font></h3>
    	<?php endif; ?>

		<p><a href="altaDom.php?id_persona=<?php echo $id_persona;?>">Nuevo domicilio</a></p>
		
		<!--<h1></h1><b><?php// echo utf8_encode($nombre); ?></b></h1> -->

		<br> <br>


		<table border="1" cellpadding="2" cellspacing="0">
			<thead>
				<tr>
					<th> ID</th>
					<th>Observacion</th>
					<th>Provincia</th>
					<th>Ciudad</th>
					<th>Barrio</th>
					<th>Calle</th>
					<th>Altura</th>
					<th>Piso</th>
					<th>Torre</th>
					<th>Manzana</th>
					<th>Sector</th>
					<th>Acciones</th>
				</tr>
			</thead>
			<tbody>
				<?php while ($row= $rs->fetch_assoc()): ?>
					<tr>
						<td> <?php echo utf8_encode($row['id_domicilio']); ?></td>
						<td> <?php echo utf8_encode($row['observacion']); ?> </td>
						<td> <?php echo utf8_encode($row['provincia']); ?> </td>
						<td> <?php echo utf8_encode($row['ciudad']); ?> </td>
						<td> <?php echo utf8_encode($row['barrio']); ?> </td>
						<td> <?php echo utf8_encode($row['calle']); ?> </td>
						<td> <?php echo ($row['altura']); ?> </td>
						<td> <?php echo ($row['piso']); ?> </td>
						<td> <?php echo ($row['torre']); ?> </td>
						<td> <?php echo ($row['manzana']); ?> </td>
						<td> <?php echo ($row['sector_parcela']); ?> </td>

						<td><a href="editar.php?id_persona=<?php echo $id_persona; ?>&id_domicilio=<?php echo $row['id_domicilio'] ?>">Editar
							</a> | 
							<a href="procesamiento/procesarBaja.php?id_persona=<?php echo $id_persona; ?>&id_domicilio=<?php echo $row ['id_domicilio']; ?>" onclick="return confirm('¿Estas seguro de que deseas eliminar el paciente?' )">Eliminar
							</a>
						</td>
					</tr>
				<!--<?php// break; ?>	-->
				<?php endwhile;?>
			</tbody>
		</table>
	</div>
</body>
</html>