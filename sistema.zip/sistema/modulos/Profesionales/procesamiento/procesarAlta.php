<?php

require '../../../php/conexion.php';

session_start();

if (!isset($_SESSION["logueado"])) {
	header("location: ../../../iniciar_sesion.php?error=debe_loguearse");
	exit;
}


$nombre = $_POST["nombre"];
$apellido = $_POST["apellido"];
$dni = $_POST["dni"];
$fechaNac= date($_POST["fechaNaci"]);
$profesion= $_POST['cboProfesion'];
$especialidad= $_POST ['cboEspecialidad'];
$matricula= $_POST['matricula'];


switch ($_POST["cboProfesion"]) {
	case '0':
		$id_profesional=3;
		break;
	case '1':
		$id_profesional=1;
		break;
	case '2':
		$id_profesional=2;
		break;
}

switch ($_POST['cboEspecialidad']) {
	case '0':
		$id_especialidad=3;
		break;
	case '1':
		$id_especialidad=1;
		break;
	case '2':
		$id_especialidad=2;
		break;
}


// cuando agrego nueva persona estado = Activo
$estado = "Activo";

// GUARDO PERSONA
$sql = "INSERT INTO personas(`nombre`,`apellido`,`DNI`,`fechanacimiento`,`estado`) " 
  ."VALUES ('$nombre','$apellido','$dni','$fechaNac','$estado')";

// si no puedo guardar, redirecciono al formualrio con mensaje de error
if (!mysqli_query($conexion, $sql)) {
	$mensaje = 'GUARDAR_PERSONA_ERROR';
	header("location:../listado.php?mensaje=$mensaje");
	exit;
}


// obtengo el id insertado en personas
$id_persona = mysqli_insert_id($conexion);


// GUARDO PROFESIONAL
$sql = "INSERT INTO profesionales (`id_persona`,`id_profesion`,`id_especialidad`,`matricula`)"
 ." VALUES('$id_persona', '$profesion','$especialidad','$matricula')";


// si no puedo guardar, redirecciono al formulario con mensaje de error
//NO N O COLOCAR, SE ESTÁ EJECUTANDO 2 VECES $rs = $conexion->query($sql) or die ($conexion->error) ;


if (!mysqli_query($conexion, $sql)) {
	$mensaje = 'GUARDAR_PROFESIONAL_ERROR';
	header("location: ../listado.php?mensaje=$mensaje");
	exit;
}

$mensaje = 'GUARDAR_PROFESIONAL_OK';
header("location: ../listado.php?mensaje=$mensaje");

?>