<?php

require '../../../php/conexion.php';

session_start();

if (!isset($_SESSION["logueado"])) {
  header("location:../../..iniciar_sesion.php?error=debe_loguearse");
  exit;
}



$persona_id= $_POST["persona_ID"];
$nombre= $_POST["nombre"];
$apellido= $_POST["apellido"];
$dni= $_POST["DNI"];
$profesion= $_POST["cboProfesion"];
$especialidad= $_POST["cboEspecialidad"];
$matricula= $_POST["matricula"];
$estado= "Activo";

// MODIFICO PERSONA
$sql = "UPDATE personas "
     ."SET nombre = '$nombre', apellido = '$apellido', "
     . "DNI = '$dni', fechanacimiento = '$fechanacimiento', estado = '$estado' "
     . "WHERE personas.id_persona = " . $persona_id;
   


// si no puedo modificar, redirecciono al formulario con mensaje de error
if (!mysqli_query($conexion, $sql)) {
  $mensaje = 'MODIFICAR_PERSONA_ERROR';
  header("location: ../editar.php?id_persona=$persona_id&mensaje=$mensaje");
  exit;
}

// MODIFICO PROFESIONAL
$sql = "UPDATE profesionales SET id_especialidad = '$especialidad', profesion='$profesion', matricula='$matricula'"
     . "WHERE id_persona = " . $persona_id;


// si no puedo guardar, redirecciono al listado con mensaje de error
if (!mysqli_query($conexion, $sql)) {
  $mensaje = 'MODIFICAR_PROFESIONAL_ERROR';
  header("location: ../editar.php?id_persona=$persona_id&mensaje=$mensaje");
  exit;
}

$mensaje = 'MODIFICAR_PROFESIONAL_OK';
header("location: ../listado.php?mensaje=$mensaje");

?>