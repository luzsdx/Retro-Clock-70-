
<?php

require '../../php/conexion.php';

session_start();

// Si no existe la variable de sesión logueado, entonces el usuario debe loguearse.
if (!isset($_SESSION["logueado"])) {
	header("location: iniciar_sesion.php?error=debe_loguearse");
	exit;
}

if (isset($_GET['mensaje'])) {
	switch ($_GET['mensaje']) {
		case 'MODIFICAR_PACIENTE_ERROR':
			$mensaje = 'Ha ocurrido un error al intentar modificar el paciente.';
			break;

		case 'MODIFICAR_PERSONA_ERROR':
			$mensaje = 'Ha ocurrido un error al intentar modificar la persona.';
			break;
	}
}

$persona_id = $_GET['id_persona'];

$sql= "SELECT * FROM personas "
      . "INNER JOIN profesionales ON profesionales.id_persona=personas.id_persona "
      . "WHERE personas.`id_persona`=".$persona_id;
 
    
$rs_persona = mysqli_query($conexion, $sql);

$sql= "SELECT * FROM profesion "
      ."INNER JOIN profesionales ON profesionales.`id_profesion`= profesion.`id_profesion` "
      ."WHERE `id_persona`=".$persona_id;  

$rs_profesion = mysqli_query($conexion, $sql);

$sql= "SELECT * FROM especialidad "
      ."INNER JOIN profesionales ON profesionales.`id_especialidad` = especialidad.`id_especialidad` "
      ."WHERE `id_persona`=". $persona_id; 

$rs_especialidad = mysqli_query($conexion, $sql);

$persona = $rs_persona->fetch_assoc();

if (!$persona) {
  header("location: listado.php?mensaje=NO_EXISTE_PERSONA");
  exit;
}



?>

<!DOCTYPE html>
<html>
<head>
	<title>Profesionales</title>
</head>
<body bgcolor="orange">
	<?php require '../../php/menu.php'; ?>
	<div align='center'>
		<h1><b>Modificar profesional</b></h1>
    	<?php if (isset($mensaje)): ?>
    		<h3><font color="red"><?php echo $mensaje; ?></font></h3>
    	<?php endif; ?>
		<form method="POST" action="procesamiento/procesarEditar.php">
			<input type="hidden" name="personaID" value="<?php echo $persona['id_persona']; ?>">
			<table border="1" cellpadding="2" cellspacing="0">
				<tbody>
      <p>
        <label>Nombre
        <input type="text" name="nombre" value = <?php echo utf8_encode($persona['nombre']); ?>>
        </label>
      </p>
      <p>
        <label>Apellido
        <input type="text" name="apellido" value = <?php echo utf8_encode($persona['apellido']); ?> >
        </label>
      </p>
      <p>
        <label>DNI
        <input type="text" name="dni"value = <?php echo utf8_encode($persona['DNI']); ?> >
        </label>
      </p>
      <p>
       <label>Fecha de Nacimiento
        <input type="date" name="fechaNaci"  placeholder="
        AAAA/MM/DD" value = <?php echo utf8_encode($persona['fechanacimiento']); ?>>
        </label>
      </p>   
      <p>
        <label> Profesión</label>
        <select name="cboProfesion" value = <?php echo utf8_encode($persona['descripcion']); ?>>
          <option value="0" >Seleccionar</option>
          <option value="1" >Odontólogo</option>

        </select>
      </p>
     <p>
        <label> Especialidad</label>
        <select name="cboEspecialidad" value = <?php echo utf8_encode($persona['descripcion']); ?>>
          <option value="0" >Seleccionar</option>
          <option value="1" >odontopediatría</option>
          <option value="2" >odontología cosmética</option>
        </select>
      </p>
      <p> <label>Matrícula
        <input type="varchar" name="matricula">
      </label>
      </p>


      <p>
        <button type="button" onclick="window.history.go(-1); return false;">Cancelar</button> &nbsp;
        <input type="submit" value="Guardar">
      </p>
				</tbody>
			</table>
		</form>
	</div>
</body>
</html>