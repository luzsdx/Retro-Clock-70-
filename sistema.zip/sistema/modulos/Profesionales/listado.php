<?php

require '../../php/conexion.php';

session_start();

// Si no existe la variable de sesión logueado, entonces el usuario debe loguearse.
if (!isset($_SESSION["logueado"])) {
	header("location: ../..iniciar_sesion.php?error=debe_loguearse");
	exit;
}

// if (isset($_GET['mensaje'])) {
// 	switch ($_GET['mensaje']) {
//         case 'GUARDAR_ASISTENTE_OK':
//             $mensaje = 'Asistente agregado correctamente.';
//             break;

// 		case 'GUARDAR_ASISTENTE_ERROR':
// 			$mensaje = 'Ha ocurrido un error al intentar crear el asistente.';
// 			break;
// 	}
// }

// $sql = "SELECT  personas.`id_persona`,tipocontacto. id_tipocontacto,`tipo_decontacto`, persona_contacto.`valor` "
// 	. "FROM profesionales "
// 	. "INNER JOIN personas ON profesionales.`id_persona`=personas.`id_persona` "
// 	. "INNER JOIN persona_contacto ON personas.`id_persona`=persona_contacto.`id_persona` "
// 	. "INNER JOIN tipocontacto ON persona_contacto.`id_tipocontacto`=tipocontacto.`id_tipocontacto` "
// 	. "WHERE tipocontacto.`id_tipocontacto`=2";

// $tFijo = mysqli_query($conexion, $sql);
// while ($datosTFijo = $tFijo->fetch_assoc()) {
// 	$arrayTFijo[] = $datosTFijo;
// }

// $sql = "SELECT personas.`id_persona`, tipocontacto. id_tipocontacto,`tipo_decontacto`, persona_contacto.`valor` "
// 	. "FROM profesionales "
// 	. "INNER JOIN personas ON profesionales.`id_persona`=personas.`id_persona` "
// 	. "INNER JOIN persona_contacto ON profesionales.`id_profesion`=persona_contacto.`id_persona` "
// 	. "INNER JOIN tipocontacto ON persona_contacto.`id_tipocontacto`=tipocontacto.`id_tipocontacto` "
// 	. "WHERE tipocontacto.`id_tipocontacto`=3";

// $email = mysqli_query($conexion, $sql);
// while ($datosEmail = $email->fetch_assoc()) {
// 	$arrayEmail[] = $datosEmail;
// }

// $sql = "SELECT  personas.`id_persona`,tipocontacto. id_tipocontacto,`tipo_decontacto`, persona_contacto.`valor` "
// 	. "FROM profesionales "
// 	. "INNER JOIN personas ON profesionales.`id_persona`=personas.`id_persona` "
// 	. "INNER JOIN persona_contacto ON personas.`id_persona`=persona_contacto.`id_persona` "
// 	. "INNER JOIN tipocontacto ON persona_contacto.`id_tipocontacto`=tipocontacto.`id_tipocontacto` "
// 	. "WHERE tipocontacto.`id_tipocontacto`=1";
// $celular = mysqli_query($conexion, $sql);
// // $datosCelular = $celular->fetch_assoc();
// while ($datosCelular = $celular->fetch_assoc()) {
// 	$arrayCelular[] = $datosCelular;
//}



// $sql = " SELECT profesionales.`id_profesional`,personas.`id_persona`, nombre,apellido, domicilios.`observacion`,`barrio`,`calle`,`altura`,
//  `piso`,`torre`,`manzana`,`sector_parcela` "
// 	. "FROM profesionales "
// 	. "INNER JOIN personas ON profesionales.`id_persona`=personas.`id_persona` "
// 	. "INNER JOIN domicilios ON personas.`id_persona`=domicilios.`id_persona`";

$sql = "SELECT profesionales.`id_profesional`,`matricula`,personas.`id_persona`, nombre,apellido,
 especialidad.`descripcion` AS 'esp' "
	. "FROM profesionales "
	. "INNER JOIN personas ON profesionales.`id_persona`=personas.`id_persona` "
	. "inner join especialidad on profesionales.`id_especialidad` = especialidad.`id_especialidad`";
$profesional = mysqli_query($conexion, $sql);
// while ($arrayProfesionales = $rs->fetch_assoc()) {
// 	$arrayprofesionales[] = $arrayProfesionales;
// }

$sql = "SELECT personas. id_persona, `nombre`,`apellido`, profesion.`descripcion` AS 'profesion', 
especialidad.`descripcion` AS 'esp', profesionales.`id_profesional`,`matricula`"
	. "FROM profesionales "
	. "inner join personas on profesionales.`id_persona`= personas.`id_persona` "
	. "inner join profesion on profesionales.`id_profesion`= profesion.`id_profesion` "
	. "inner join especialidad on profesionales.`id_especialidad` = especialidad.`id_especialidad`";


//descripcion contacto=  contacto
$rs = mysqli_query($conexion, $sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" type="text/css" href="../../bootstrap-4.5.0-dist/css/bootstrap.css">
	<link href="/sistema/fontawesome/css/all.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="/sistema/css/font.css">
	<link rel="stylesheet" type="text/css" href="/sistema/css/cuenta.css?1.1">
</head>

<body>
	<?php require '../../dashboard.php'; ?>

	<div class="container">
		<div class="card">
			<div class="card-header">Profesionales </div>
			<div class="body">
				<div class="table-responsive table-sm">
					<table class="table table-bordered">
						<thead class="cabeza-header">
							<tr>
								<th rowspan="2" class="text-center centrarT" style="vertical-align: middle">Apellido</th>
								<th rowspan="2" class="text-center centrarT" style="vertical-align: middle">Nombre </th>
								<th rowspan="2" class="text-center centrarT" style="vertical-align: middle">Matrícula </th>
								<th rowspan="2" class="text-center centrarT" style="vertical-align: middle">Especialidad</th>
								<th rowspan="2" class="text-center centrarT" style="vertical-align: middle">Acciones</th>
							</tr>
							<!-- <tr>
								<th>Celular</th>
								<th>Teléf.Fijo</th>
								<th>E-mail</th>
							</tr> -->
						</thead>
						<tbody>
							<!-- Loop de empleados -->
							<!-- <?php //foreach ($arrayProfesionales as $row) : 
									?> -->
							<tr>
								<?php while ($row = $profesional->fetch_assoc()) : ?>
									<td><?php echo utf8_encode($row['apellido']); ?></td>
									<td><?php echo utf8_encode($row['nombre']); ?></td>
									<td><?php echo utf8_encode($row['matricula']); ?></td>
									<td><?php echo utf8_encode($row['esp']); ?></td>
									</td>
									<td>
										<div class="btn-group btn-group-toggle d-flex justify-content-center">
											<button type="button" class="btn btn-sm butMod" data-toggle="modal" data-target="#modificarProfesional<?php echo $row['id_Profesional']; ?>"><i class="fas fa-edit"></i></button>
											<button type="button" class="btn btn-sm butDel"><i class="fas fa-trash-alt"></i></button>
										</div>
									</td>
									<?php //endforeach; 
									?>
							</tr>
						<?php endwhile; ?>

						</tbody>
					</table>
				</div>
			</div>
		</div>

	</div>

</body>

</html>