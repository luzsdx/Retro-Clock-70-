<?php

require('../../php/conexion.php');

session_start();

// Si no existe la variable de sesión logueado, entonces el usuario debe loguearse.
if (!isset($_SESSION["logueado"])) {
  header("location: ../../php/iniciar_sesion.php?error=debe_loguearse");
  exit;
}





?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Profesionales</title>
</head>
<body bgcolor="orange">

  <div align="center">

    <font color="white" face="Verdana, Arial, Helvetica, sans-serif">



   <h1>Alta de profesionales</h1>


    <br>

    <form method="POST" action="procesamiento/procesarAlta.php">

      <h3>Ingrese los datos del profesional</h3>
      <p>
        <label>Nombre
        <input type="text" name="nombre" required>
        </label>
      </p>
      <p>
        <label>Apellido
        <input type="text" name="apellido" required>
        </label>
      </p>
      <p>
        <label>DNI
        <input type="text" name="dni" required >
        </label>
      </p>
      <p>
       <label>Fecha de Nacimiento
        <input type="date" name="fechaNaci" required placeholder="
        AAAA/MM/DD">
        </label>
      </p>   
      <p>
        <label> Profesion</label>
        <select name="cboProfesion" required>
          <option value="0" >Seleccionar</option>
          <option value="1" >Odontólogo</option>
        </select>
      </p>
     <p>
        <label> Especialidad</label>
          <select name="cboEspecialidad" required>
          <option value="0" >Seleccionar</option>
          <option value="1" >odontopediatría</option>
          <option value="2" >odontología cosmética</option>
        </select>
      </p>
      <p> <label>Matrícula
        <input type="varchar" name="matricula" required>
      </label>
      </p>


      <p>
        <button type="button" onclick="window.history.go(-1); return false;">Cancelar</button> &nbsp;
        <input type="submit" value="Guardar">
      </p>
    </form>
    
  </div>

  

</body>
</html>