<?php

require '../../php/conexion.php';

session_start();

// Si no existe la variable de sesión logueado, entonces el usuario debe loguearse.
if (!isset($_SESSION["logueado"])) {
	header("location: ../../iniciar_sesion.php?error=debe_loguearse");
	exit;
}

if (isset($_GET['mensaje'])) {
	switch ($_GET['mensaje']) {
        case 'GUARDAR_PACIENTE_OK':
            $mensaje = 'Paciente agregado correctamente.';
            break;

		case 'GUARDAR_PACIENTE_ERROR':
			$mensaje = 'Ha ocurrido un error al intentar crear el Paciente.';
			break;

		case 'GUARDAR_PERSONA_ERROR':
			$mensaje = 'Ha ocurrido un error al intentar crear la persona.';
			break;
	}
}


$sql = "SELECT personas.`id_persona`, nombre, apellido, DNI, fechanacimiento, cargo.`descripcion` AS 'cargo', empleados.`id_empleado` "
     ."FROM empleados "
     ."INNER JOIN personas ON empleados.`id_persona`= personas.`id_persona` "
     ."INNER JOIN cargo ON empleados.`id_cargo`= cargo.`id_cargo`";


//descripcion contacto=  contacto
$rs = mysqli_query($conexion, $sql);
?>

<!DOCTYPE html>
<html>
<head>
	<title>Listado de empleados</title>
</head>
<body bgcolor="orange">
	<?php require '../../php/menu.php'; ?>
	<div align='center'>
		<h1><b>Listado de Empleados</b></h1>

    	<?php if (isset($mensaje)): ?>
    		<h3><font color="red"><?php echo $mensaje; ?></font></h3>
    	<?php endif; ?>

		<p><a href="altaEmp.php">Nuevo empleado</a></p>
		<br>
		<table border="1" cellpadding="2" cellspacing="0">
			<thead>
				<tr>
					<th>ID</th>
					<th>Apellido</th>
					<th>Nombre</th>
					<th>Cargo</th>
					<th>Domicilios</th>
					<th>Contactos</th>
					<th>Acciones</th>
				</tr>
			</thead>
			<tbody>
				<?php while ($row = $rs->fetch_assoc()): ?>
					<tr>
						<td><?php echo utf8_encode($row['id_empleado']); ?> </td>
						<td> <?php echo utf8_encode($row['nombre']); ?> </td>
						<td> <?php echo utf8_encode($row['apellido']); ?> </td>
						<td> <?php echo utf8_encode($row['cargo']); ?></td>
						<td>  <a href="../domicilio/listado.php?id_persona=<?php echo $row['id_persona']; ?>">Ver</a> </td>
					    <td> <a href="../contacto/listado.php?id_persona=<?php echo $row['id_persona']; ?>">Ver</a> </td>

						<td><a href="editar.php?id_persona=<?php echo $row['id_persona']; ?>">
							    Editar
							</a> | 
							<a href="procesamiento/procesarBaja.php?id_persona=<?php echo $row['id_persona']; ?>" onclick="return confirm('¿Estas seguro de que deseas eliminar el paciente?' )">
							    Eliminar
							</a>

					</tr>
				<?php endwhile; ?>
			</tbody>
		</table>
	</div>
</body>
</html>