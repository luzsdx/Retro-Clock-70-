 <div class="row ">
     <div class="col-md-4">
         <div class="d-flex justify-content-center">Seleccione paciente</div>
         <div class="m-0">
             <input class="datalist pacInput" autocomplete="off" list="browsers" placeholder="Pacientes" name="paciente" id="browser">
             <datalist id="browsers">
                 <option value="<?php foreach ($arrayPaciente as $paciente) {
                                    if ($paciente['id_paciente'] == $paciente['rela_persona']) {
                                        echo $paciente['apellido'] . $paciente['nombre'];
                                    }
                                }
                                ?>">
                 </option>
             </datalist>
         </div>
     </div>
     <div class="col-md-4">
         <div class="d-flex justify-content-center">Dientes existentes</div>
         <div class="input-group d-flex justify-content-center">
             <input type="text" aria-label="First name" class="form-control">
             <input type="text" aria-label="Last name" class="form-control">
         </div>
     </div>
     <div class="col-md-4">
         <div class="d-flex justify-content-center">Color</div>
         <div class="input-group d-flex justify-content-center">
             <input type="text" aria-label="First name" class="form-control">
             <input type="text" aria-label="Last name" class="form-control">
         </div>
     </div>
 </div>
 <br>
 <div class="row ">
     <div class="col-md-8 odontograma">
         <div class="card">
             <div class="card-body">
                 <!-- <div class="card-title text-center p-2"><h5>Odontograma</h5></div> -->
                 <br>
                 <div class="piezaFila1">
                     <p class="pieza18" id="pieza18">18</p> 
                     <p class="pieza17" id="pieza17">17</p>
                     <p class="pieza16" id="pieza16">16</p>
                     <p class="pieza15" id="pieza15">15</p>
                     <p class="pieza14" id="pieza14">14</p>
                     <p class="pieza13" id="pieza13">13</p>
                     <p class="pieza12" id="pieza12">12</p>
                     <p class="pieza11" id="pieza11">11</p>
                     <p class="pieza21" id="pieza21">21</p>
                     <p class="pieza22" id="pieza22">22</p>
                     <p class="pieza23" id="pieza23">23</p>
                     <p class="pieza24" id="pieza24">24</p>
                     <p class="pieza25" id="pieza25">25</p>
                     <p class="pieza26" id="pieza26">26</p>
                     <p class="pieza27" id="pieza27">27</p>
                     <p class="pieza28" id="pieza28">28</p>
                 </div>
                 <div class="fila1 d-flex justify-content-center">
                     <div class="pieza18"><img src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza17"><img src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza16"><img src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza15"><img src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza14"><img src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza13"><img src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza12"><img src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza11"><img src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="mr-3 ml-3"></div>
                     <div class="pieza21"><img src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza22"><img src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza23"><img src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza24"><img src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza25"><img src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza26"><img src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza27"><img src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza28"><img src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>

                     <!-- <img class="pieza17" src="../../imagenes/caraDentalVacia.png" alt="">
                     <img class="pieza16" src="../../imagenes/caraDentalVacia.png" alt="">
                     <img class="pieza15" src="../../imagenes/caraDentalVacia.png" alt="">
                     <img class="pieza14" src="../../imagenes/caraDentalVacia.png" alt="">
                     <img class="pieza13" src="../../imagenes/caraDentalVacia.png" alt="">
                     <img class="pieza12" src="../../imagenes/caraDentalVacia.png" alt="">
                     <img class="pieza11" src="../../imagenes/caraDentalVacia.png" class="separadorPieza" alt="">
                     <img class="pieza21" src="../../imagenes/caraDentalVacia.png" alt="">
                     <img class="pieza22" src="../../imagenes/caraDentalVacia.png" alt="">
                     <img class="pieza23" src="../../imagenes/caraDentalVacia.png" alt="">
                     <img class="pieza24" src="../../imagenes/caraDentalVacia.png" alt="">
                     <img class="pieza25" src="../../imagenes/caraDentalVacia.png" alt="">
                     <img class="pieza26" src="../../imagenes/caraDentalVacia.png" alt="">
                     <img class="pieza27" src="../../imagenes/caraDentalVacia.png" alt="">
                     <img class="pieza28" src="../../imagenes/caraDentalVacia.png" alt=""> -->
                 </div>
                 <div class="fila2 d-flex justify-content-center">
                     <div class="pieza48"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza47"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza46"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza45"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza44"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza43"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza42"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza41"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="mr-3 ml-3"></div>

                     <div class="pieza31"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza32"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza33"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza34"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza35"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza36"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza37"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza38"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                 </div>
                 <div class="piezaFila2">
                     <p class="pieza48" id="pieza48">48</p>
                     <p class="pieza47" id="pieza47">47</p>
                     <p class="pieza46" id="pieza46">46</p>
                     <p class="pieza45" id="pieza45">45</p>
                     <p class="pieza44" id="pieza44">44</p>
                     <p class="pieza43" id="pieza43">43</p>
                     <p class="pieza42" id="pieza42">42</p>
                     <p class="pieza41" id="separador pieza41">41</p>
                     <p class="pieza31" id="pieza31">31</p>
                     <p class="pieza32" id="pieza32">32</p>
                     <p class="pieza33" id="pieza33">33</p>
                     <p class="pieza34" id="pieza34">34</p>
                     <p class="pieza35" id="pieza35">35</p>
                     <p class="pieza36" id="pieza36">36</p>
                     <p class="pieza37" id="pieza37">37</p>
                     <p class="pieza38" id="pieza38">38</p>
                 </div>
                 <div class="piezaFila3">
                     <p class="pieza55" id="pieza55 ">55</p>
                     <p class="pieza54" id="pieza54">54</p>
                     <p class="pieza53" id="pieza53">53</p>
                     <p class="pieza52" id="pieza52">52</p>
                     <p class="pieza51" id="pieza51">51</p>
                     <p class="pieza61" id="pieza61">61</p>
                     <p class="pieza62" id="pieza62">62</p>
                     <p class="pieza63" id="pieza63">63</p>
                     <p class="pieza64" id="pieza64">64</p>
                     <p class="pieza65" id="pieza65">65</p>
                 </div>
                 <div class="fila3 d-flex justify-content-center">
                     <div class="pieza55"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza54"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza53"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza52"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza51"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="mr-3 ml-3"></div>

                     <div class="pieza61"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza62"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza63"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza64"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza65"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                 </div>
                 <div class="fila4 d-flex justify-content-center">
                     <div class="pieza85"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza84"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza83"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza82"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza81"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="mr-3 ml-3"></div>
                     <div class="pieza71"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza72"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza73"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza74"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                     <div class="pieza75"><img class="pieza18" src="../../imagenes/caraDentalVacia.png" alt="">
                     </div>
                 </div>
                 <div class="piezaFila4">
                     <p class="pieza85" id="pieza85">85</p>
                     <p class="pieza84" id="pieza84">84</p>
                     <p class="pieza83" id="pieza83">83</p>
                     <p class="pieza82" id="pieza82">82</p>
                     <p class="pieza81" id="pieza81">81</p>
                     <p class="pieza71" id="pieza71">71</p>
                     <p class="pieza72" id="pieza72">72</p>
                     <p class="pieza73" id="pieza73">73</p>
                     <p class="pieza74" id="pieza74">74</p>
                     <p class="pieza75" id="pieza75">75</p>
                 </div>
             </div>
         </div>
     </div>
     <div class="col-md-4">
         <div class="card ">
             <div class="card-body ">
                 <div>Seleccione el tipo de prestación requerida:</div>
                 <div class="row">
                     <div class="col-md-12 d-flex justify-content-left">
                         <div class="form-inline">
                             <input type="radio" id="prestExistente" name="colorPrestacion" value="1">
                             <div class="mr-1"></div>
                             <font style="color:red"> Prestaciones existentes</font>
                         </div>
                     </div>
                 </div>
                 <div class="row">
                     <div class="col-md-12 d-flex justify-content-left">
                         <div class="form-inline">
                             <input type="radio" id="prestRequerida" name="colorPrestacion" value="2">
                             <div class="mr-1"></div>
                             <font style="color:blue"> Prestaciones requeridas</font>
                         </div>
                     </div>
                 </div>
                 <br>
                 <div class="row">
                     <div class=" col-md-12 d-flex justify-content-left">
                         <button type="button" class="btn undoRedo" data-toggle="tooltip" data-placement="top" title="Deshacer"><i class="fas fa-undo-alt"></i></button>
                         <div class="mr-1"></div>
                         <button type="button" class="btn undoRedo" data-toggle="tooltip" data-placement="top" title="Rehacer"><i class="fas fa-redo-alt"></i></button>
                         <br>
                     </div>
                 </div>
                 <form id="tratamientos" action="">
                     <div>Seleccione la pieza dental requerida:</font>
                         <div class="m-1"></div>
                         <div class="row">
                             <div class="col-md-6">
                                 <select name="pzaDentaria" id="denticionPSelect" class="form-control">
                                     <option value='' selected disabled>Pza.Permanente</option>
                                     <?php while ($row1 = $rs_denticionPer->fetch_assoc()) : ?>
                                         <option value="<?php echo $row1['id_pieza_dentaria']; ?>">
                                             <?php echo utf8_encode($row1['numero']); ?>
                                         </option>
                                     <?php endwhile; ?>
                                 </select>
                             </div>
                             <div class="col-md-6">
                                 <select name="pzaDentaria" id="denticionTSelect" class="form-control">
                                     <option value='' selected disabled>Pza.Temporal</option>
                                     <?php while ($row2 = $rs_denticionTem->fetch_assoc()) : ?>
                                         <option value="<?php echo $row2['id_pieza_dentaria']; ?>">
                                             <?php echo utf8_encode($row2['numero']); ?>
                                         </option>
                                     <?php endwhile; ?>
                                 </select>
                             </div>
                         </div>
                         <div class="m-1"></div>
                         <div>Seleccione referencia y cara, en caso de ser necesario:</font>
                             <div class="m-1"></div>
                             <div class="row">
                                 <div class="col-md-6">
                                     <select class="form-control" name="tratamientos" id="tratSelect">
                                         <option value='' selected disabled>Seleccione referencia</option>
                                         <?php while ($row3 = $rs_tratamientos->fetch_assoc()) : ?>
                                             <option value=" <?php echo $row3['id_tipo_trat'];  ?>">
                                                 <?php echo utf8_encode($row3['tipo_trat_descrip']); ?>
                                             </option>
                                         <?php endwhile; ?>
                                     </select>
                                 </div>
                                 <div class="col-md-6">
                                     <select name="" class="form-control caraSelect">
                                         <option value='' selected disabled>Seleccione cara</option>
                                         <?php while ($row4 = $rs_cara->fetch_assoc()) : ?>
                                             <option value="<?php echo $row4['id_cara'];  ?>">
                                                 <?php echo utf8_encode($row4['nombre']);
                                                    ?>
                                             </option>
                                         <?php endwhile; ?>
                                     </select>
                                 </div>
                                 <div class="m-1"></div>
                                 <div class="col-md-12">
                                     <label for="Observación" class="obserSelect">Observación</label>
                                     <textarea class="form-control" id="Observación"></textarea>
                                 </div>
                             </div>
                             <br>
                 </form>
                 <div class="row">
                     <div class="col-md-12 d-flex justify-content-center">
                         <button type="button" class="btn btn-primary" style="width:100%">Guardar cambios</button>
                     </div>
                 </div>
             </div>
         </div>

     </div>
 </div>
 </div>
 </body>
 <script type="text/javascript">
     // console.log('jquery funciona')
     // $("p[class='pieza1^']").css('margin-left': '12px', 'margin-right': '10px')
     // $('div').css('width': '35px', 'height'; '35px;')

     // window.onload=function(){
     //     document.getElementById("p").style.color = blue;
     // document.getElementsByClassName("[class^=pieza1]").style.marginLeft='12px';
     // document.getElementsByClassName("[class^=pieza1]").style.marginRight='10px';
     // }
 </script>