// obtener la opcion de un select
// https://blog.trescomatres.com/2012/07/jquery-como-seleccionar-una-opcion-de-select/#:~:text=Veamos%20la%20sentencia%20para%20seleccionar,(%22selected%22%2Ctrue)%3B
//:selectd
// https://stackoverflow.com/questions/13089944/jquery-get-selected-option-value-not-the-text-but-the-attribute-value
$(document).ready(function () {
    //deshabilitar los selects hasta que se seleccione un tipo de prestación
    if (!$('input[id^="prest"').is(":checked")) {
        $('select').attr('disabled', true)
        // $('textarea').attr('disabled', true)
    }
    $('input[id^="prest"').on('click', function () {
        $('select[id$="Select"]').attr('disabled', false)
    })
    // si se selecciona prestacción existente mientras quiere marcar extr.indicada, alerta que no es posible
    $("#tratSelect").on('change', function () {
        if ($("#tratSelect").val() == 2) {
            if ($("input[name='colorPrestacion']".val() == 2)) {
                alert('Extracción indicada es una prestación requerida')
            }
            //  if($("input[name='colorPrestacion']:checked")){
            //    alert($("input[name='colorPrestacion']").val())
            //  }
        }
        // habilitar select de CARAS cuando se selecciona obturacion/caries
        if ($("tratSelect").val() == 5) {
            var valorTrat = $("#refSelect").val();
            if (valorTrat === "Obturación/Caries") {
                $('.refCaras').attr('disabled', false)
            }
        }
    });
 
})    
