<?php

require '../../php/conexion.php';


$sql= "SELECT tipo_tratamiento.`id_tipo_trat`, tipo_trat_descrip FROM tipo_tratamiento";
$rs=mysqli_query($conexion, $sql);

$sql="SELECT*FROM caras";
$rs_cara=mysqli_query($conexion, $sql);

$sql="SELECT*FROM tipo_tratamiento";
$rs_tratamientos=mysqli_query($conexion, $sql);

$sql="SELECT*FROM pzas_dentarias "
."WHERE pzas_dentarias.id_pieza_dentaria<16 ";
$rs_denticionPer=mysqli_query($conexion, $sql);

$sql="SELECT*FROM pzas_dentarias "
."WHERE pzas_dentarias.id_pieza_dentaria>16 ";
$rs_denticionTem=mysqli_query($conexion, $sql);


$sql = "SELECT pacientes.`id_paciente`, rela_persona, personas. id_persona,`nombre`, apellido, 
per_estado. estado AS 'estado de paciente '" .
    "FROM pacientes " .
    "INNER JOIN personas ON pacientes.`rela_persona`= personas.`id_persona` " .
    "INNER JOIN per_estado ON pacientes.`id_per_estado`=per_estado.`id_per_estado`" .
    "WHERE per_estado.estado= 'Activo'";
$rs = mysqli_query($conexion, $sql);
while ($datosPaciente = $rs->fetch_assoc()) {
    $arrayPaciente[] = $datosPaciente;
}




?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevo Odontograma</title>
    <link rel="stylesheet" type="text/css" href="../../bootstrap-4.5.0-dist/css/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=PT+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="/sistema/css/font.css">
    <link rel="stylesheet" href="demoOdont.css?1.8">
    <link rel="stylesheet" href="demoOdont2.css">    
    <link rel="stylesheet" type="text/css" href="/sistema/css/cuenta.css?.1.0.1" media="all">
    <script src="https://kit.fontawesome.com/775f36926d.js" crossorigin="anonymous"></script>

</head>

<body>
    <?php require '../../dashboard.php'; ?>
    <!-- PARA LAS IMAGENES PNG https://www.online-image-editor.com/?language=spanish -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header cabeza-header d-flex justify-content-center "> <b class="odonTitulo">Nuevo odontograma</b></div>
                    <div class="card-body">
                        <div class="body">
                            <?php require 'odonto.php'; ?>
                        </div>
                        <br>
                    </div>
                </div>
            </div>
        </div>
        <br>
    </div>
    <br>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="card-title d-flex justify-content-center"><h5>Nuevo plan de tratamiento</h5></div>
                        <hr>
                        <div class="body">
                            <?php require 'planTratamiento.php'; ?>
                        </div>
                        <br>
                    </div>
                </div>
            </div>
        </div>
        <br>
    </div>
    <br>
</body>
<script src="/sistema/js/jquery-3.5.1.min.js" ></script>
<script src="odonto.js" type="text/javascript">
</script>
<script src="../../bootstrap-4.5.0-dist/js/bootstrap.bundle.js"></script>

</html>