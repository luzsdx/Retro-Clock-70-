<div class="table-responsive table-sm">
    <table class="table table-bordered">
        <thead class="thead table-dark">
            <tr>
                <th rowspan="2" class="text-center centrarT" style="vertical-align: middle">Fecha</th>
                <th colspan="3" class="text-center centrarT" style="vertical-align: middle">Plan de tratamiento </th>
                <th rowspan="2" class="text-center centrarT" style="vertical-align: middle">Observación</th>
            </tr>
            <tr>
                <th>Tratamiento</th>
                <th>Pza.Dental</th>
                <th>Sector</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th>idsahsa</th>
                <th>idsahsa</th>
                <th>idsahsa</th>
                <th>idsahsa</th>
                <th>idsahsa</th>
            </tr>
        </tbody>
    </table>