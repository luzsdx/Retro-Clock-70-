<?php

require('../../php/conexion.php');

session_start();

// Si no existe la variable de sesión logueado, entonces el usuario debe loguearse.
if (!isset($_SESSION["logueado"])) {
  header("location: ../../php/iniciar_sesion.php?error=debe_loguearse");
  exit;
}


$id_persona= $_GET["id_persona"];

$sql= "SELECT * FROM tipocontacto";
$rs_tipocontacto=mysqli_query($conexion, $sql);


/*if($id_persona==""){
  echo "dato vacio";
}else{
  echo $id_persona;
}
exit(); */


?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Nuevo</title>
</head>
<body bgcolor="orange">

  <div align="center">

    <font color="white" face="Verdana, Arial, Helvetica, sans-serif">



   <h1>Crear contacto</h1>

    <br>

    <form method="POST" action="procesamiento/procesarAlta.php?id_persona<?php echo $id_persona= $_GET['id_persona'];?>">
      <input type="hidden" name="ID" value="<?php echo $id_persona;?>">



      <h3>Ingrese los datos del contacto</h3>

      <p>
         Tipo de contacto <select name="cbotipocontacto">
            <?php while ($row = $rs_tipocontacto->fetch_assoc()): ?>
              <option value="<?php echo $row['id_tipocontacto']; ?>">
                <?php echo $row["descripcion"]; ?>
                </option>
              <?php endwhile; ?>
          </select>
      </p>
      <p>
        <label>Descripcion
        <input type="text" name="descripcionc" >
        </label>
      </p>
      <p>
        <button type="button" onclick="window.history.go(-1); return false;">Cancelar</button> &nbsp;
        <input type="submit" value="Guardar">
      </p>


    </form>
    
  </div>

  

</body>
</html>