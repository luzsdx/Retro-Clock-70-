<?php

require '../../php/conexion.php';

$nombre=$_POST['nombre'];
$apellido=$_POST['apellido'];
$celularValor=$_POST['celular'];
$tFijoValor=$_POST['tFijo'];
$emailValor=$_POST['email'];
$celular='1';
$tFijo='2';
$email='3';

if(!empty($_POST['especialidad'])){
    $nombre = $_POST['nombre'];
} else {
    return false;
}

$persona="INSERT INTO personas (nombre,apellido) "
."VALUES ('$nombre', '$apellido')";
mysqli_query($conexion, $persona);
$id_persona=mysqli_insert_id($conexion);


$empleado="INSERT INTO empleados (id_persona) "
."VALUES ($id_persona)";
if (!mysqli_query($conexion, $empleado)) {
    echo 'no se guardo el empleado'. mysqli_error($conexion);
}else
    echo ' se guardo el empleado';


$celular="INSERT INTO persona_contacto(id_persona, id_tipocontacto, valor) "
. "VALUES ($id_persona, $celular, $celularValor)";
mysqli_query($conexion,$celular);

$tFijo="INSERT INTO persona_contacto(id_persona, id_tipocontacto, valor) "
. "VALUES ($id_persona, $tFijo', $tFijoValor)";
mysqli_query($conexion, $tFijo);

$email="INSERT INTO persona_contacto(id_persona, id_tipocontacto, valor) "
. "VALUES ($id_persona, $email, '$emailValor')";
mysqli_query($conexion, $email);

// if (!mysqli_query($conexion, $email)) {
//     echo 'no se guardo el email'. mysqli_error($conexion);
// }else
//     echo ' se guardo el email';
// $varArray=array($persona, $empleado, $tipocontacto1, $tipocontacto2, $tipocontacto3, $celular, $tFijo, $email);
// $varValores= compact($varArray);
// $arrEmpleado=implode($varValores);

// var_dump($arrempleado);

// $json=array();
// while ($row=mysqli_fetch_array($arrEmpleado)) {
//     $json[]=array(
//         'nombre'=>$row['nombre'],
//         'apellido'=>$row['apellido'],
//         'celular'=>$row['celular'],
//         'tFijo'=>$row['tFijo'],
//         'email'=>$row['email']
//     )
// };
// $jsonstring=json_encode($json);
// echo $jsonstring

?>