$(document).ready(function(){
console.log('jquery esta funcionando')
        $('#formEmpleados').on("submit", function (e){
            e.preventDefault()
            var postDatos= {
                nombre: $('#nombre').val(),
                apellido:$('#apellido').val(),
                celular:$('#celular').val(),
                tFijo:$('#tFijo').val(),
                email:$('#email').val()
            }
        $.ajax({
            url:'alta.php',
            type:'POST',
            data:postDatos,
            success:function(respuesta){
                console.log(respuesta)
                $('#formEmpleados').trigger('reset')
            }
        })    

    })

    function fetchLista(){
        $.ajax({
            url:'lista.php',
            type: 'GET',
            success:function(respuesta){
                let listas = JSON.parse (response);
                let template ='';
                listas.forEach(lista => {
                    template += `
                    <tr> 
                    <td>${lista.nombre} </td>
                    <td>${lista.apellido} </td>
                    <td> <button type="button" class="btn btn-sm domB" data-toggle="modal" data-target="#domicilio">Ver más</button> </td>
                    <td>${lista.celular}</td>
                    <td>${lista.tFijo}</td>
                    <td>${lista.email}</td>
                    </tr
                    `
                });
                $('#tasks').html(template)
            }
        })         
    }
}) 

