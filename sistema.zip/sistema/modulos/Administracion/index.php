<?php

require '../../php/conexion.php';

session_start();

// Si no existe la variable de sesión logueado, entonces el usuario debe loguearse.
if (!isset($_SESSION["logueado"])) {
	header("location: ../../iniciar_sesion.php?error=debe_loguearse");
	exit;
}



//descripcion contacto=  contacto
$sql = "SELECT  personas.`id_persona`,tipocontacto. id_tipocontacto,`tipo_decontacto`, persona_contacto.`valor` "
	. "FROM empleados "
	. "INNER JOIN personas ON empleados.`id_persona`=personas.`id_persona` "
	. "INNER JOIN persona_contacto ON personas.`id_persona`=persona_contacto.`id_persona` "
	. "INNER JOIN tipocontacto ON persona_contacto.`id_tipocontacto`=tipocontacto.`id_tipocontacto` "
	. "WHERE tipocontacto.`id_tipocontacto`=1";
$celular = mysqli_query($conexion, $sql);
// $datosCelular = $celular->fetch_assoc();
while ($datosCelular = $celular->fetch_assoc()) {
	$arrayCelular[] = $datosCelular;
}



$sql = "SELECT  personas.`id_persona`,tipocontacto. id_tipocontacto,`tipo_decontacto`, persona_contacto.`valor` "
	. "FROM empleados "
	. "INNER JOIN personas ON empleados.`id_persona`=personas.`id_persona` "
	. "INNER JOIN persona_contacto ON personas.`id_persona`=persona_contacto.`id_persona` "
	. "INNER JOIN tipocontacto ON persona_contacto.`id_tipocontacto`=tipocontacto.`id_tipocontacto` "
	. "WHERE tipocontacto.`id_tipocontacto`=2";

$tFijo = mysqli_query($conexion, $sql);
while ($datosTFijo = $tFijo->fetch_assoc()) {
	$arrayTFijo[] = $datosTFijo;
}


$sql = "SELECT personas.`id_persona`, tipocontacto. id_tipocontacto,`tipo_decontacto`, persona_contacto.`valor` "
	. "FROM empleados "
	. "INNER JOIN personas ON empleados.`id_persona`=personas.`id_persona` "
	. "INNER JOIN persona_contacto ON empleados.`id_empleado`=persona_contacto.`id_persona` "
	. "INNER JOIN tipocontacto ON persona_contacto.`id_tipocontacto`=tipocontacto.`id_tipocontacto` "
	. "WHERE tipocontacto.`id_tipocontacto`=3";

$email = mysqli_query($conexion, $sql);
while ($datosEmail = $email->fetch_assoc()) {
	$arrayEmail[] = $datosEmail;
}


$sql = " SELECT empleados.`id_empleado`,personas.`id_persona`, nombre,apellido, domicilios.`observacion`,`barrio`,`calle`,`altura`,
 `piso`,`torre`,`manzana`,`sector_parcela` "
	. "FROM empleados "
	. "INNER JOIN personas ON empleados.`id_persona`=personas.`id_persona` "
	. "INNER JOIN domicilios ON personas.`id_persona`=domicilios.`id_persona`";

$rs = mysqli_query($conexion, $sql);
while ($empleados = $rs->fetch_assoc()){
	$arrayEmpleados[] = $empleados;
}

$sql = " SELECT precio.`fecha` AS 'precio fecha', valor, tipo_tratamiento. id_tipo_trat, `tipo_trat_descrip`  AS 'tratamiento' "
	. "FROM tratamiento "
	. " INNER JOIN precio ON tratamiento.`id_precio`=precio.`id_precio` "
	. "INNER JOIN tipo_tratamiento ON tratamiento.`id_tipo_trat`=tipo_tratamiento.`id_tipo_trat` ";
$rs_precio_trat = mysqli_query($conexion, $sql);
$tratamiento = $rs_precio_trat->fetch_assoc();


?>

<!DOCTYPE html>
<html>

<head>
	<title>Administración</title>
	<link rel="stylesheet" type="text/css" href="../../bootstrap-4.5.0-dist/css/bootstrap.css">
	<link href="/sistema/fontawesome/css/all.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="/sistema/css/font.css">
	<link rel="stylesheet" type="text/css" href="/sistema/css/cuenta.css?1.1">

	<style type="text/css">
		.relleno {
			background-color: #f6fff8;
		}

		.centrarT {
			vertical-align: middle;
		}

		.domB {
			background-color: #98c9a3;
			color: #084c61;
		}
	</style>
</head>

<body>
	<?php require '../../dashboard.php'; ?>

	<div class="container-fluid">
		<div class="row">
			<div class="col-md-8">
				<div class="card">
					<div class="card-header cabeza-header">Empleados</div>
					<div class="card-body">
						<?php require 'empleados.php'; ?>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="card">
					<div class="card-header cabeza-header">Precio de tratamientos</div>
					<div class="card-body"><?php require 'tratamientos.php'; ?></div>
				</div>
			</div>
		</div>

	</div>
	<script src="../../js/jquery-3.5.1.min.js"></script>
	<script src="../../bootstrap-4.5.0-dist/js/bootstrap.bundle.js"></script>
	<script src="https://unpkg.com/@popperjs/core@2"></script>
</body>
<script>
	$(document).ready(function() {
		$('body').on('#agregarEmpleado'.click, function() {
			$('#modal').modal(show);
		})
	})
</script>

</html>