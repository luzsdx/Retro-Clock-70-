<?php 

require  '../../php/conexion.php';

$sql = "SELECT  personas.`id_persona`,tipocontacto. id_tipocontacto,`tipo_decontacto`, persona_contacto.`valor` "
	. "FROM empleados "
	. "INNER JOIN personas ON empleados.`id_persona`=personas.`id_persona` "
	. "INNER JOIN persona_contacto ON personas.`id_persona`=persona_contacto.`id_persona` "
	. "INNER JOIN tipocontacto ON persona_contacto.`id_tipocontacto`=tipocontacto.`id_tipocontacto` "
	. "WHERE tipocontacto.`id_tipocontacto`=1";
$rsCelulares = mysqli_query($conexion, $sql);

$arrayCelulares = array();
while($row=mysqli_fetch_array($rsCelulares)){
    $arrayCelulares[] = $row;
}


$sql = "SELECT  personas.`id_persona`,tipocontacto. id_tipocontacto,`tipo_decontacto`, persona_contacto.`valor` "
	. "FROM empleados "
	. "INNER JOIN personas ON empleados.`id_persona`=personas.`id_persona` "
	. "INNER JOIN persona_contacto ON personas.`id_persona`=persona_contacto.`id_persona` "
	. "INNER JOIN tipocontacto ON persona_contacto.`id_tipocontacto`=tipocontacto.`id_tipocontacto` "
	. "WHERE tipocontacto.`id_tipocontacto`=2";

$rsTFijo = mysqli_query($conexion, $sql);

$arrayTFijos = array();
while($row=mysqli_fetch_array($rsTFijo)){
    $arrayTFijos[] = $row;
}



$sql = "SELECT personas.`id_persona`, tipocontacto. id_tipocontacto,`tipo_decontacto`, persona_contacto.`valor` "
	. "FROM empleados "
	. "INNER JOIN personas ON empleados.`id_persona`=personas.`id_persona` "
	. "INNER JOIN persona_contacto ON empleados.`id_empleado`=persona_contacto.`id_persona` "
	. "INNER JOIN tipocontacto ON persona_contacto.`id_tipocontacto`=tipocontacto.`id_tipocontacto` "
	. "WHERE tipocontacto.`id_tipocontacto`=3";

$rsEmail = mysqli_query($conexion, $sql);

$arrayEmail = array();
while($row=mysqli_fetch_array($rsEmail)){
    $arrayEmail[] = $row;
}

$sql = " SELECT empleados.`id_empleado`,personas.`id_persona`, nombre,apellido, domicilios.`observacion`,`barrio`,`calle`,`altura`,
 `piso`,`torre`,`manzana`,`sector_parcela` "
	. "FROM empleados "
	. "INNER JOIN personas ON empleados.`id_persona`=personas.`id_persona` "
	. "INNER JOIN domicilios ON personas.`id_persona`=domicilios.`id_persona`";

$persona = mysqli_query($conexion, $sql);



$json=array();
while ($row=mysqli_fetch_array($persona)){
    $arrayTemp = array(
        'id_persona' =>$row['id_persona'],
        'nombre'=> $row['nombre'],
        'apellido' => $row['apellido']
    );
    foreach($arrayCelulares as $celular){
        if($row['id_persona'] == $celular['id_persona']){
            $arrayTemp['celular'] = $celular['valor'];
        }
    }
    foreach($arrayTFijos as $tFijo){
        if($row['id_persona'] == $tFijo['id_persona']){
            $arrayTemp['tFijo'] = $tFijo['valor'];
        }
    }
    foreach($arrayEmail as $email){
        if($row['id_persona'] == $email['id_persona']){
            $arrayTemp['email'] = $email['valor'];
        }
    }
    $json[] = $arrayTemp;
}


$jsonstring=json_encode($json);
echo $jsonstring;
?>