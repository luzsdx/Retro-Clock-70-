<div class="mb-3">
  <button type="button" class="btn btn-sm butNew" data-toggle="modal" data-target="#agregar"><i class="fas fa-briefcase-medical"></i>
    Nuevo tratamiento</button>
</div>
<div class="table-responsive table-sm">
  <table class="table table-bordered">
    <thead class="thead cabeza-header">
      <tr>
        <th>Tratamiento</th>
        <th>Precio</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tr>
      <td><?php echo utf8_encode($tratamiento['tratamiento']); ?> </td>
      <td><?php echo utf8_encode($tratamiento['valor']); ?></td>
      <td>
        <div class="btn-group btn-group-toggle d-flex justify-content-center">
          <button type="button" class="btn btn-sm butMod" data-toggle="modal" data-target="#editar"><i class="fas fa-edit"></i></button>
          <button type="button" class="btn btn-sm butDel"><i class="fas fa-trash-alt"></i></button>
        </div>
      </td>
    </tr>
  </table>
</div>

<!-- Modificar tratamiento -->
<div class="modal fade" id="editar" tabindex="-1" role="dialog" aria-labelledby="editarLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editarLabel">Editar</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-md-12">
            Tratamiento
            <input type="text" readonly value="<?php echo utf8_encode($tratamiento['tratamiento']); ?>" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            Precio <font style="color:red">*</font>
            <input type="text" value="<?php echo utf8_encode($tratamiento['valor']); ?>" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
<!-- fin modificar tratamiento  -->

<!-- agregar tratamiento -->
<div class="modal fade" id="agregar" tabindex="-1" role="dialog" aria-labelledby="agregarLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="agregarLabel">Nuevo Tratamiento</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-md-12">
            Tratamiento
            <input list="tratamientos" name="tratamientos" id="tratamientos">
            <datalist id="tratamientos">
             <?php while(!$tratamiento=="") ?> 
              <option value="<?php echo utf8_encode($tratamiento['id_tipo_trat']); ?>">
              <option value="<?php echo utf8_encode($tratamiento['tipo_trat_descrip']); ?>">
            </datalist>
            <input type="submit">
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            Precio <font style="color:red">*</font>
            <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>

<!-- fin agregar tratamiento -->