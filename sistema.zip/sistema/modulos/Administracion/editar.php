
<?php

require '../../php/conexion.php';

session_start();

// Si no existe la variable de sesión logueado, entonces el usuario debe loguearse.
if (!isset($_SESSION["logueado"])) {
	header("location: ../../../iniciar_sesion.php?error=debe_loguearse");
	exit;
}

if (isset($_GET['mensaje'])) {
	switch ($_GET['mensaje']) {
		case 'MODIFICAR_PACIENTE_ERROR':
			$mensaje = 'Ha ocurrido un error al intentar modificar el paciente.';
			break;

		case 'MODIFICAR_PERSONA_ERROR':
			$mensaje = 'Ha ocurrido un error al intentar modificar la persona.';
			break;
	}
}

$persona_id = $_GET['id_persona'];

$sql= "SELECT * FROM personas "
      . "INNER JOIN pacientes ON pacientes.id_persona=personas.id_persona "
      . "WHERE personas.`id_persona`=".$persona_id;

   $rs_persona = $conexion->query($sql) or die($conexion->error);


$sql=  "SELECT * FROM cargo "
     ."INNER JOIN empleados on empleados.`id_cargo`= cargos.`id_cargo` "
     ."WHERE empleados.id_cargo =". $persona_id;

$rs_cargos = mysqli_query($conexion, $sql);




$persona = $rs_persona->fetch_assoc();

if (!$persona) {
	header("location: listado.php?mensaje=NO_EXISTE_PERSONA");
	exit;
}



?>

<!DOCTYPE html>
<html>
<head>
	<title>Empleados</title>
</head>
<body bgcolor="orange">
	<?php require '../../php/menu.php'; ?>
	<div align='center'>
		<h1><b>Modificar empleado</b></h1>
    	<?php if (isset($mensaje)): ?>
    		<h3><font color="red"><?php echo $mensaje; ?></font></h3>
    	<?php endif; ?>
		<form method="POST" action="procesamiento/procesarEditar.php">
			<input type="hidden" name="personaID" value="<?php echo $persona['id_persona']; ?>">
			<table border="1" cellpadding="2" cellspacing="0">
				<tbody>
      <p>
        <label>Nombre
        <input type="text" name="nombre" value = <?php echo utf8_encode($persona['nombre']); ?>>
        </label>
      </p>
      <p>
        <label>Apellido
        <input type="text" name="apellido" value = <?php echo utf8_encode($persona['apellido']); ?> >
        </label>
      </p>
      <p>
        <label>DNI
        <input type="text" name="dni"value = <?php echo utf8_encode($persona['DNI']); ?> >
        </label>
      </p>
      <p>
       <label>Fecha de Nacimiento
        <input type="date" name="fechaNaci"  placeholder="
        AAAA/MM/DD" value = <?php echo utf8_encode($persona['fechanacimiento']); ?>>
        </label>
      </p>   
      <p>
         Cargo <select name="cboCargo">
            <?php while ($row = $rs_cargos->fetch_assoc()): ?>
              <?php
                if ($datos['id_cargo'] == $row['id_cargo']):
                  $selected = 'selected';
                else: 
                  $selected = '';
                endif ?>
              <option <?php echo $selected ?> value="<?php echo $row['id_cargo']; ?>">
                <?php echo $row["cargo"]; ?>
                </option>
              <?php endwhile; ?>
          </select>
      </p>
      <p>
        <button type="button" onclick="window.history.go(-1); return false;">Cancelar</button> &nbsp;
        <input type="submit" value="Guardar">
      </p>
				</tbody>
			</table>
		</form>
	</div>
</body>
</html>