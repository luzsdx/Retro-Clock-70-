<div class="mb-3">
    <button type="button" id="agregarEmpleado" class="btn btn-sm butNew" data-toggle="modal" data-target="#agregarEmpleado"><i class="fas fa-user-plus"></i>Nuevo empleado</button>

</div>
<div class="table-responsive table-sm">
    <table class="table table-bordered">
        <thead class="cabeza-header">
            <tr>
                <th rowspan="2" class="text-center centrarT" style="vertical-align: middle">Apellido</th>
                <th rowspan="2" class="text-center centrarT" style="vertical-align: middle">Nombre </th>
                <th rowspan="2" class="text-center centrarT" style="vertical-align: middle">Domicilio</th>
                <th colspan="3" class="text-center centrarT" style="vertical-align: middle">Contactos </th>
                <th rowspan="2" class="text-center centrarT" style="vertical-align: middle">Acciones</th>
            </tr>
            <tr>
                <th>Celular</th>
                <th>Teléf.Fijo</th>
                <th>E-mail</th>
            </tr>
        </thead>
        <tbody>
            <!-- Loop de empleados -->
            <?php foreach ($arrayEmpleados as $row) : ?>
                <tr>
                    <td><?php echo utf8_encode($row['apellido']); ?></td>
                    <td><?php echo utf8_encode($row['nombre']); ?></td>
                    <td>
                        <div class="d-flex justify-content-center"><button type="button" class="btn btn-sm domB" data-toggle="modal" data-target="#domicilio"><i class="fas fa-info-circle">Ver</i></button></div>
                    </td>
                    <td>
                        <?php
                        foreach ($arrayCelular as $rowCelular) {
                            if ($row['id_persona'] == $rowCelular['id_persona']) {
                                echo $rowCelular['valor'];
                            } // elseif ($rowCelular['valor']=null) {
                            // 	echo '-';
                            // }
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        foreach ($arrayTFijo as $rowTfijo) {
                            if ($row['id_persona'] == $rowTfijo['id_persona']) {
                                echo $rowTfijo['valor'];
                            }
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        foreach ($arrayEmail as $rowEmail) {
                            if ($row['id_persona'] == $rowEmail['id_persona']) {
                                echo $rowEmail['valor'];
                            }
                        }
                        ?>
                    </td>
                    <td>
                        <div class="btn-group btn-group-toggle d-flex justify-content-center">
                            <button type="button" class="btn btn-sm butMod" data-toggle="modal" data-target="#modificarEmpleado<?php echo $row['id_empleado']; ?>"><i class="fas fa-edit"></i></button>
                            <button type="button" class="btn btn-sm butDel"><i class="fas fa-trash-alt"></i></button>
                        </div>
                    </td>
                <?php endforeach; ?>
                </tr>
        </tbody>
    </table>
</div>
<!-- modal de nuevo empleado -->
<div class="modal fade" id="agregarEmpleado" tabindex="-1" role="dialog" aria-labelledby="domicilio" aria-hidden="true">
    <div class=" modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Agregar empleado</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        Nombre <font style="color:red">*</font>
                        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                    </div>
                    <div class="col-md-6">
                        Apellido <font style="color:red">*</font>
                        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-md-4">
                        Celular
                        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                    </div>
                    <div class="col-md-4">
                        Teléf.Fijo
                        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                    </div>
                    <div class="col-md-4">
                        E-mail
                        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-md-6">
                        Barrio
                        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                    </div>
                    <div class="col-md-6">
                        Calle
                        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-md-3">
                        Altura
                        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">

                    </div>
                    <div class="col-md-3">
                        Piso
                        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">

                    </div>
                    <div class="col-md-3">
                        Torre
                        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-md-6">
                        Manzana
                        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                    </div>
                    <div class="col-md-6">
                        Sector/Parcela
                        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-md-12">
                        Observación
                        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- fin modal nuevo empleado -->

<!-- Modificar empleado -->
<?php foreach ($arrayEmpleados as $row) : ?>
    <div class="modal show" id="modificarEmpleado<?php echo $row['id_empleado']; ?>" tabindex="-1" role="dialog" aria-labelledby="modificarEmpleado" aria-hidden="true">
        <div class=" modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Modificar empleado</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            Nombre <font style="color:red">*</font>
                            <input type="text" value="<?php echo utf8_encode($row['nombre']); ?>" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                        </div>
                        <div class="col-md-6">
                            Apellido <font style="color:red">*</font>
                            <input type="text" value="<?php echo utf8_encode($row['apellido']); ?>" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-md-4">
                            Celular
                            <input type="text" value="" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                        </div>
                        <div class="col-md-4">
                            Teléf.Fijo
                            <input type="text" value="" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                        </div>
                        <div class="col-md-4">
                            E-mail
                            <input type="text" value="" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-md-6">
                            Barrio
                            <input type="text" value="<?php echo utf8_encode($row['barrio']); ?>" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                        </div>
                        <div class="col-md-6">
                            Calle
                            <input type="text" value="<?php echo utf8_encode($row['calle']); ?>" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-md-3">
                            Altura
                            <input type="text" value="<?php echo utf8_encode($row['altura']); ?>" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">

                        </div>
                        <div class="col-md-3">
                            Piso
                            <input type="text" value="<?php echo utf8_encode($row['piso']); ?>" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">

                        </div>
                        <div class="col-md-3">
                            Torre
                            <input type="text" value="<?php echo utf8_encode($row['torre']); ?>" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-md-6">
                            Manzana
                            <input type="text" value="<?php echo utf8_encode($row['manzana']); ?>" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                        </div>
                        <div class="col-md-6">
                            Sector/Parcela
                            <input type="text" value="<?php echo utf8_encode($row['sector_parcela']); ?>" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-md-12">
                            Observación
                            <input type="text" value="<?php echo utf8_encode($row['observacion']); ?>" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>
<!-- fin Modificar empleado-->


<!--Modal Alta Domicilios -->
<div class="modal fade" id="domicilio" tabindex="-1" role="dialog" aria-labelledby="domicilio" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Domicilio de X</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        Barrio
                        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                    </div>
                    <div class="col-md-6">
                        Calle
                        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3">
                        Altura
                        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">

                    </div>
                    <div class="col-md-3">
                        Piso
                        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">

                    </div>
                    <div class="col-md-3">
                        Torre
                        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        Manzana
                        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                    </div>
                    <div class="col-md-6">
                        Sector/Parcela
                        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        Observación
                        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>
    <!-- fin AltaDom -->

</div>