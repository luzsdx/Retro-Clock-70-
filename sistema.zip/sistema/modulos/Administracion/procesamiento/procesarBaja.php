<?php

require ('../../../php/conexion.php');

session_start();

if (!isset($_SESSION["logueado"])) {
	header("location:../../..iniciar_sesion.php?error=debe_loguearse");
	exit;
}

$persona_id = $_GET['id_persona'];

// MODIFICO PERSONA
$sql = "UPDATE personas SET estado = 'Inactivo' WHERE id_persona= " . $persona_id;

// si no puedo modificar, redirecciono al formulario con mensaje de error
if (!mysqli_query($conexion, $sql)) {
	$mensaje = 'PERSONA_ESTADO_UPDATE_ERROR';
	header("location: ../listado.php?mensaje=$mensaje");
	exit;
}

$mensaje = 'PERSONA_ESTADO_UPDATE_OK';
header("location: ../listado.php?mensaje=$mensaje");

?>