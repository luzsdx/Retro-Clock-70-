<?php

require '../../../php/conexion.php';

session_start();

if (!isset($_SESSION["logueado"])) {
	header("location:../../..iniciar_sesion.php?error=debe_loguearse");
	exit;
}

$table='cargo';

$persona_id=$_POST["personaID"];
$nombre= $_POST["nombre"];
$apellido= $_POST["apellido"];
$dni= $_POST["dni"];
$fechanacimiento= $_POST["fechaNaci"];
$cargo= $_POST['cboCargo'];

$estado= "Activo";

// MODIFICO PERSONA
$sql = "UPDATE personas SET nombre = '$nombre', apellido = '$apellido', "
     . "DNI = '$dni', fechanacimiento = '$fechanacimiento', estado = '$estado' "
     . "WHERE id_persona = " . $persona_id;


// si no puedo modificar, redirecciono al formulario con mensaje de error
if (!mysqli_query($conexion, $sql)) {
	$mensaje = 'MODIFICAR_PERSONA_ERROR';
	echo("location: ../editar.php?id_persona=$persona_id&mensaje=$mensaje");
	exit;
}

// MODIFICO PACIENTE
$sql = "UPDATE empleados SET id_cargo = '$cargo' "
     . "WHERE id_persona = " . $persona_id;




// si no puedo guardar, redirecciono al listado con mensaje de error
if (!mysqli_query($conexion, $sql)) {
	$mensaje = 'MODIFICAR_EMPLEADO_ERROR';
	header("location: ../editar.php?id_persona=$persona_id&mensaje=$mensaje");
	exit;
}

$mensaje = 'MODIFICAR_EMPLEADO_OK';
header("location: ../listado.php?mensaje=$mensaje");

?>