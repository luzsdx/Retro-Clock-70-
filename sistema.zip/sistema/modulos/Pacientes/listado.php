<?php

require '../../php/conexion.php';

session_start();

// Si no existe la variable de sesión logueado, entonces el usuario debe loguearse.
if (!isset($_SESSION["logueado"])) {
	header("location: ../../iniciar_sesion.php?error=debe_loguearse");
	exit;
}


$sql = "SELECT pacientes.`id_paciente`,fechaingreso, personas. id_persona,`nombre`, apellido, DNI, fechanacimiento, 
 obrasocial.`descripcion`AS 'obra social', per_estado. estado AS 'estado de paciente'
 FROM pacientes " .
	"INNER JOIN personas ON pacientes.`rela_persona`= personas.`id_persona` " .
	"INNER JOIN obrasocial ON pacientes.`id_obrasocial`=obrasocial.`id_obrasocial` " .
	"INNER JOIN per_estado ON pacientes.`id_per_estado`=per_estado.`id_per_estado`" .
	"WHERE per_estado.estado= 'Activo'";
$rs = mysqli_query($conexion, $sql);




?>


<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Pacientes</title>
	<link rel="stylesheet" type="text/css" href="/sistema/bootstrap-4.5.0-dist/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="/sistema/css/cuenta.css?1.4" media="all">
	<script src="/sistema/fontawesome/js/all.js" crossorigin="anonymous"></script>
	<style type="text/css" media="screen">
		.pointer {
			cursor: pointer;
		}
	</style>
</head>

<body>
	<?php require '../../php/dist/menu.php'; ?>
	<br>
	<?php if (isset($mensaje)) : ?>
		<h3>
			<font color="red"><?php echo $mensaje; ?></font>
		</h3>
	<?php endif; ?>
	<div class="container">

		<div class="card shadow borderCard">
			<div class="card-header cabeza-header "> Lista de Pacientes </font>
			</div>
			<div class="card-body">
				<div class="card">
					<div class="card-body">
						<div class="row text-left">
							<div class="col-sm-2">
								Desde
								<br>
								<input type="date" name="fecha" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
							</div>
							<div class="col-sm-2">
								Hasta
								<br>
								<input type="date" name="fecha" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
							</div>
							<div class="col-md-2">
								<br>
								<button type="button" class="btn btn-primary"><i class="fas fa-calendar-week"></i>Filtrar</button>
							</div>
							<div class="col-sm-4">
								Nombre y/o Apellido
								<br>
								<div class="input-group mb-3">
									<input type="search" name="buscador" class="form-control" id="busqueda" aria-describedby="basic-addon2">
									<div class="input-group-append">
									</div>
								</div>
							</div>
							<div class="col-md-2">
								<br>
								<button type="button" class="btn btn-primary"><i class="fas fa-search"></i>Buscar</button>
							</div>
						</div>
					</div>
				</div>
				<br>

				<div class="float-left">
					<!-- <a href="add.php" class="btn btn-success butNew">Añadir Paciente</a>    		 -->
					<a href="alta.php" class="btn butNew"> <i class="fas fa-hospital-user"></i>Añadir Paciente</a>
					<a href="bajas.php" class="btn butDel"> <i class="fas fa-user-alt-slash"></i>Pacientes dados de baja</a>
				</div>

				<!--En caso de que no haya resultados de la búsqueda
    	-->
				<section id="tabla_resultados">

				</section>
				<!-- -->


				<div class="table-responsive">

					<table id="listadoPacientes" class="table table-hover table-bordered">
						<br>
						<thead class="cabeza-header" ;>
							<tr>
								<th>Apellido</th>
								<th>Nombre</th>
								<th>DNI</th>
								<th>Fecha de nacimiento</th>
								<th>Fecha Ingreso</th>
								<th>Obra social</th>
								<th>Estado</th>
								<th>Acciones</th>
							</tr>
						</thead>
						<tbody>

							<?php while ($row = $rs->fetch_assoc()) : ?>
								<tr>
									<td> <?php echo utf8_encode($row['apellido']); ?> </td>
									<td> <?php echo utf8_encode($row['nombre']); ?> </td>
									<td> <?php echo utf8_encode($row['DNI']); ?> </td>
									<td> <?php echo utf8_encode($row['fechanacimiento']); ?> </td>
									<td> <?php echo utf8_encode($row['fechaingreso']); ?> </td>
									<td> <?php echo utf8_encode($row['obra social']); ?> </td>
									<td> <span class="badge badge-pill pacActivo"><?php echo utf8_encode($row['estado de paciente']); ?></span> </td>
									<td>
										<div class="btn-group btn-group-toggle d-flex justify-content-center">
											<button type="button" class="btn btn-sm butMod">
												<a href="modificar.php?id_paciente= <?php echo $row['id_paciente']; ?>">
													<i class="fas fa-edit"></i></a>
											</button>
											<button type="button" class="btn btn-sm butDel">
												<a href="delete.php?id_paciente= <?php echo $row['id_paciente']; ?>">
												</a><i class="fas fa-trash-alt"></i></a>
											</button>
										</div>
									</td>
									<!-- <span class="badge badge-pill badge-danger pointer pasarId" 
									data-toggle="modal" data-target="#baja" 
									data-id=" <?php // echo $row['nombre'] . " " . $row['apellido']; 
												?> ">Dar de baja</span>|

										<span class="badge badge-pill badge-primary"><a href="perfil.php?id_persona=<?php// echo $row['id_persona']; ?>" style="color:white">Ver más</a> </span> -->
								</tr>
							<?php endwhile; ?>
						</tbody>
					</table>
					<br>
				</div>
				<!-- PAGINACION --->
				<nav aria-label="Page navigation">
					<ul class="pagination">
						<li>
							<a href="index.php?page=<?= $Previous; ?>" aria-label="Previous">
								<span aria-hidden="true">&laquo; Previous</span>
							</a>
						</li>
						<li class="page-item"><a class="page-link" href="index.php?page=<?= $i; ?>"><?= $i; ?></a></li>
						<a href="index.php?page=<?= $Next; ?>" aria-label="Next">
							<span aria-hidden="true">Next &raquo;</span>
						</a>
						</li>
					</ul>
				</nav>
			</div>
		</div>
	</div>
	<!-- PAGINACION --->

	<!-- Modal de DAR DE BAJA --->
	<div class="modal fade" id="baja" tabindex="-1" role="dialog" aria-labelledby="baja" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="bajaLabel">Dar de baja Paciente</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					¿Está seguro de dar de baja el paciente <input type="text" readonly id="showId"> ?
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
					<button type="button" id="showId" value="" onclick="baja()" class="btn btn-primary">Aceptar</button>
				</div>
			</div>
		</div>
	</div>
	<!-- Modal de DAR DE BAJA --->

</body>
<script src="/sistema/jquery-3.4.1.min.js"></script>
<script src="/sistema/bootstrap-4.4.1-dist/js/bootstrap.bundle.js"></script>

</html>