<?php
require '../../php/conexion.php';
if (count($_FILES["imagen"]["tmp_name"]>0)) {

	for ($count=0; $count<count($_FILES["imagen"]["tmp_name"]); $count++);
}
	$imagen=addcslashes(file_get_contents($_FILES['imagen']['tmp_name'])[$count]);
	$query="INSERT INTO exam_auxiliar VALUES ('$imagen')";

	$rs=mysqli_query($conexion,$query);
?>

 
