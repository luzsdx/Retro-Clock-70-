//si la persona es hombre, los campos de embarazo se deshabilitan
$("#datosPersonales").click("input[id^=genero]", function () {
    if ($("#generoM").is(":checked")) {
        //deshabilitar el div de select
        $("div[id=pregDiv]").prop("disabled", true).fadeTo(0, 0.5)
        $(this).find("input[id='embarazoRadio']").prop("disabled", true)
        //deshabilita la opcion de seleccionar
        $("div[id=pregMDiv]").prop("disabled", true).fadeTo(0, 0.5)
        $(this).find('#mesesSelect').prop("disabled", true)

    } else if ($("#generoF").is(":checked")) {
        $("div[id=pregDiv]").prop("disabled", false).fadeTo(0, 1)
        $(this).find("input[id='embarazoRadio']").prop("disabled", false)

        $("div[id=pregMDiv]").prop("disabled", false).fadeTo(0, 1)
        $(this).find('#mesesSelect').prop("disabled", false)

    }
})
//si es mujer y no esta embarazada el campo de meses se deshabilita
$('div[id=pregDiv]').click("input[id$=Emb]", function () {
    if ($("#noEmb").is(":checked")) {
        $('div[id=pregMDiv]').prop('disabled', true).fadeTo(0, 0.5)
    } else if ($("#siEmb").is(":checked")) {
        $('div[id=pregMDiv]').prop('disabled', false).fadeTo(0, 1)
    }
})

//si selecciona "sin especificar" de la obra social, entonces el campo de nro afiliado se deshabilita

//if ($('select[id=obraSocial], option:selected').not(' option[value=sinEspecificar]')) {
//	$('#div_afiliado').prop('disable', true).fadeTo(0,0.5)
//}
//validar


// $("#datosPersonales").validate({
//     rules: {
//         nombre: {
//             required: true,
//             rangelength: [3, 20]
//         },
//         apellido: {
//             required: true,
//             rangelength: [3, 20]
//         },
//         dni: {
//             required: true,
//             rangelength: [6, 10]
//         },
//         nacimiento: {
//             required: true,
//         },
//         ingreso: {
//             required: true,
//         },
//         genero: {
//             required: true
//         }
//     },
//     messages: {
//         nombre: {
//             required: "Ingresar nombre del paciente",
//             rangelength: "El nombre debe contener 3 a 20 caracteres"
//         },
//         apellido: {
//             required: "Ingresar apellido del paciente",
//             rangelength: "El apellido debe contener 3 a 20 caracteres"
//         },
//         dni: {
//             required: "Ingresar DNI del paciente",
//             rangelength: "El DNI debe contener 6 a 10 caracteres"
//         },
//         nacimiento: {
//             required: "Seleccionar fecha de nacimiento del paciente"
//         },
//         ingreso: {
//             required: "Seleccionar fecha de ingreso del paciente",
//         },
//         genero: {
//             required: "Seleccione el género del paciente"
//         }
//     }
// })

function prueba() {
    $('#datosPersonales').on("submit", function () {
        $.ajax({
            url: "altaDatosP.php",
            type: "POST",
            dataType: "JSON",
            data: {
                "nombre": $('#nombre').val(),
                "apellido": $('#apellido').val(),
                "dni": $('#dni').val(),
                "nacimiento": $('#nacimiento').val(),
                "fechaingreso": $('#ingreso').val(),
                "embarazo": $('input[name="embarazada"]').val(),
                "mesesSelect": $('#mesesSelect').val(),
                "obraSocial": $('#obraSocial').val(),
                "afiliado": $('#afiliado').val(),
                "observacion": $('#observacion').val(),
                "celular": $('#celular').val(),
                "fijo": $('#fijo').val(),
                "correo": $('#correo').val(),
                "provincia": $('#provincia').val(),
                "ciudad": $('#ciudad').val(),
                "barrio": $('#barrio').val(),
                "calle": $('#calle').val(),
                "altura": $('#altura').val(),
                "piso": $('#piso').val(),
                "manzana": $('#manzana').val(),
                "sector": $('#sector').val(),
                "observacionDom": $('#observacionDom').val(),
                "genero": $('input[name="genero"]').val(),
                "ocupacion": $('#ocupacion').val(),
            },
            success: function (respuesta) {
                console.log(respuesta)
                $("#datosPersonales").trigger('reset')
            }

        })

    })

}
