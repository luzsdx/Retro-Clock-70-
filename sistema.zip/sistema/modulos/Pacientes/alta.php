<?php

require '../../php/conexion.php';

session_start();

// Si no existe la variable de sesión logueado, entonces el usuario debe loguearse.
if (!isset($_SESSION["logueado"])) {
  header("location: ../../..iniciar_sesion.php?error=debe_loguearse");
  exit;
}

//$persona_id=$_GET['id_persona'];

//$sql= "SELECT * FROM personas "
     // . "INNER JOIN pacientes ON pacientes.id_persona=personas.id_persona "
     // . "WHERE personas.`id_persona`=".$persona_id;

//$rs_persona = $conexion->query($sql) or die($conexion->error);

//$persona = $rs_persona->fetch_assoc();

$sql= "SELECT * FROM ocupacion ";

$rs_ocupacion= mysqli_query($conexion,$sql);

$sql= "SELECT * FROM obrasocial";

$rs_obrasocial=mysqli_query($conexion,$sql);


?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Nuevo Paciente</title>
	<link rel="stylesheet" type="text/css" href="/sistema/css/cuenta.css?1.6" media="all"  >
	<link rel="stylesheet" type="text/css" href="../../bootstrap-4.5.0-dist/css/bootstrap.css">
<style>
	 .lista a .resaltarLista {
		background-color: #f6fff8;
	}
</style>

</head>
	<?php require '../../php/dist/menu.php'; ?>
<br>
<!-- <body style="background: #212d40"> -->
<body class="bg-gradient-primary">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-3">
				<div class="text-center">
    			   <img src="/sistema/imagenes/imgPac.png " class=" border border-success img-thumbnail borde-imagen" style="width: 150px ", style="height: 150px">					
				</div>
				<div class="text-center">Nuevo Paciente</div>
				<div class="list-group lista" id="listaAlta" role="tablist">
				      <a class="list-group-item list-group-item-action active" id="list-home-list" data-toggle="list" href="#datospersonales" role="tab" aria-controls="home">Datos Personales</a>
				      <a class="list-group-item list-group-item-action" id="list-profile-list" data-toggle="list" href="#hclinica" role="tab" aria-controls="profile">Historia Clínica</a>	
				      <a class="list-group-item list-group-item-action" id="list-messages-list" data-toggle="list" href="#examenes" role="tab" aria-controls="messages">Exámenes auxiliares</a>
				      <a class="list-group-item list-group-item-action" id="list-settings-list" data-toggle="list" href="#recetas" role="tab" aria-controls="settings">Recetas</a>
				      <a class="list-group-item list-group-item-action" id="list-settings-list" data-toggle="list" href="#recetas" role="tab" aria-controls="settings">Odontograma</a>
				</div>
			  </div>
			  <div class="col-md-9">
			  	 <div class="tab-content" id="nav-tabContent">
			  	  <div class="tab-pane fade show active" id="datospersonales" role="tabpanel" aria-labelledby="list-home-list">
			      	<div class="card shadow">
			      		<div class="card-header cabeza-header">Datos Personales </font></div>
			      		<div class="card-body">
			      			<div class="p-3">
			      			<?php include 'datosP.php'; ?>
			      		</div>
			  	 </div>
			  	 <div class="tab-pane fade" id="hclinica" role="tabpanel" aria-labelledby="list-profile-list">
			  	 	<div class="card shadow">
			      		<div class="card-header cabeza-header" >Historia Clínica </font></div>
			      		<div class="card-body">
							<ul class="nav nav-tabs" id="myTab" role="tablist">
								<!--Comienzo historia clinica gral  -->
							  <li class="nav-item">
							    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#hcgeneral" role="tab" aria-controls="home" aria-selected="true">Historia Clínica General</a>
							  </li>
							  <!-- Fin historia clinica gral -->

							  <!-- Comienzo historia clinica odontologica -->
							  <li class="nav-item">
							    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#hcodontologica" role="tab" aria-controls="profile" aria-selected="false">Historia Clínica Odontológica</a>
							  </li>
							  <!--Fin historia clinica odontologica  -->

							  <!-- Comienzo alergias -->
							  <li class="nav-item">
							    <a class="nav-link" id="contact-tab" data-toggle="tab" href="#alergias" role="tab" aria-controls="contact" aria-selected="false">Alergías</a>
							  </li>
							   <!--Fin alergias  --> 
							</ul>	
							<div class="tab-content" id="myTabContent">
								<!--Comienzo panel historia clinica gral  -->
								<br>								
							  <div class="tab-pane fade show active" id="hcgeneral" role="tabpanel" aria-labelledby="home-tab"><?php require 'hcgeneral.php'; ?> </div>
							  <!--Fin panel historia clinica gral -->

							  <!-- Comienzo panel historia clinica odontologica-->
							   <div class="tab-pane fade" id="hcodontologica" role="tabpanel" aria-labelledby="profile-tab"> <?php include 'hcodontologica.php'; ?></div> 
							  <!-- Fin panel historia clinica odontologica -->							  						  
							</div>
						</div>	
					 </div>
					</div> 
					      <div class="tab-pane fade" id="examenes" role="tabpanel" aria-labelledby="list-messages-list">
							  <div class="card">
								<div class="card-header cabeza-header">Exámenes auxiliares</div>	
								<div class="card-body">
									<?php include 'examenesA.php'; ?>
							  </div>	
					       </div>

					      <div class="tab-pane fade" id="recetas" role="tabpanel" aria-labelledby="list-settings-list">.</div>				
			      	</div>
			  	 </div>
			      <div class="tab-pane fade" id="examenes" role="tabpanel" aria-labelledby="list-messages-list">	      		
			      	</div>
			      </div>
			      <div class="tab-pane fade" id="recetas" role="tabpanel" aria-labelledby="list-settings-list">.</div>			      		  	 
			  </div>						
			</div>
		</div>		
	</div>	
</body>
<script src="/sistema/jquery-3.4.1.min.js">
</script>
<script type="text/javascript" src="/sistema/js/jquery.validate.js"></script>
<script src="pacDPersonales.js" type="text/javascript">
	$('#listaAlta').on('click', 'div a', function(event) {
  $(this).addClass('resaltarLista').siblings().removeClass('resaltarLista');
});
</script>
<!-- <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script> -->
<script src="/sistema/bootstrap-4.5.0-dist/js/bootstrap.bundle.js"></script> 

</html>