<!-- <!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
	<link rel="stylesheet" type="text/css" href="/sistema/bootstrap-4.4.1-dist/css/bootstrap.min.css">
</head>
<body> -->

	<br>
	<form id="hcOdontologica">
		<div class="row text-left resaltar">
			<div class="col-md-4">
				<input type="checkbox" id="check1" class="" onclick="deshabilitar(this.id)">
				<label class="labelCheck1">Motivo de la consulta</label>
				<textarea name="motivoConsulta" class="form-control" aria-label="With textarea"></textarea>
			</div>
			<div class="col-md-6">
				<input type="checkbox" id="check2" class="" onclick="deshabilitar(this.id)">
				<label class="labelCheck2">¿Consultó antes con algún profesional?</label>
				<div class="form-inline">
					<div class="form-inline radio1">
						<label for="op1" class="mr-1">Si</label>
						<input type="radio" id="op1" name="motivoConsulta">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio 2">
						<label for="op2" class="mr-1">No</label>
						<input type="radio" id="op2" name="motivoConsulta">
					</div>
					<br>
				</div>
			</div>
		</div>
		<br>
		<div class="row text-left resaltar">
			<div class="col-md-3 ">
				<input type="checkbox" class="" id="check3" onclick="deshabilitar(this.id)" >
				<label class="labelCheck3">¿Tomó algún medicamento?</label>
				<div class="form-inline">
					<div class="form-inline radio3">
						<label for="op3" class="mr-1">Si</label>
						<input type="radio" id="op3" name="tomoMedicamento">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio4">
						<label for="op4" class="mr-1">No</label>
						<input type="radio" id="op4" name="tomoMedicamento">
					</div>
				</div>
			</div>
			<div class="col-md-4 medInfo">
				<label class="labelCheck3">Nombre de los medicamentos</label>
				<textarea name="nombreMedicamentos" id="medInfo" class="form-control" aria-label="With textarea"></textarea>
			</div>
			<div class="col-md-3 ">
				<label class="labelCheck3">¿Desde cuando?</label>
				<input type="text" id="" name="desdeCuanMedicam" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
			</div>
			<div class="col-md-2 ">
				<label class="labelCheck2">¿Obtuvo resultados?</label>
				<div class="form-inline">
					<div class="form-inline radio5">
						<label for="op5" class="mr-1">Si</label>
						<input type="radio" id="op5" class="medInfoRadio" name="tomoMedicamento">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio6">
						<label for="op6" class="mr-1">No</label>
						<input type="radio" id="op6" class="medInfoRadio" name="tomoMedicamento">
					</div>
				</div>				
			</div>
		</div>
		<br>
		<div class="row text-left resaltar">
			<div class="col-md-3">
				<input type="checkbox" id="check4" class="" onclick="deshabilitar(this.id)">
				<label class="labelCheck4">¿Ha tenido dolor?</label>
				<div class="form-inline">
					<div class="form-inline radio7">
						<label for="op7" class="mr-1">Si</label>
						<input type="radio" id="op7" name="tenidoDolor">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio8">
						<label for="op8" class="mr-1">No</label>
						<input type="radio" id="op8" name="tenidoDolor">
					</div>
				</div>
			</div>
			<div class="col-md-8 dolorInfo" >
				<label class="labelCheck4">¿De qué tipo?</label>
				<div class="form-inline">
					<div class="form-inline radio9">
						<label for="op9" class="mr-1">Suave</label>
						<input type="radio" id="op9" class="dolorInfo" name="tipoDolor">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio10">
						<label for="op10" class="mr-1">Moderado</label>
						<input type="radio" id="op10" class="dolorInfo" name="tipoDolor">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio11">
						<label for="op11" class="mr-1">Intenso</label>
						<input type="radio" id="op11" class="dolorInfo" name="tipoDolor">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio12">
						<label for="op12" class="mr-1">Temporario</label>
						<input type="radio" id="op12" class="dolorInfo" name="tipoDolor">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio13">
						<label for="op13" class="mr-1">Intermitente</label>
						<input type="radio" id="op13" class="dolorInfo" name="tipoDolor">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio14">
						<label for="op14" class="mr-1">Continuo</label>
						<input type="radio" id="op14" class="dolorInfo" name="tipoDolor">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio15">
						<label for="op15" class="mr-1">Espontáneo</label>
						<input type="radio" id="op15" class="dolorInfo" name="tipoDolor">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio16">
						<label for="op16" class="mr-1">Provocado</label>
						<input type="radio" id="op16" class="dolorInfo" name="tipoDolor">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio17">
						<label for="op17" class="mr-1">Al frío</label>
						<input type="radio" id="op17" class="dolorInfo" name="tipoDolor">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio18">
						<label for="op18" class="mr-1">Al calor</label>
						<input type="radio" id="op18" class="dolorInfo" name="tipoDolor">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio19">
						<label for="op19" class="mr-1">Localizado</label>
						<input type="radio" id="op19" class="dolorInfo" name="tipoDolor">
					</div>
					<div class="mr-2"></div>					
					<div class="form-inline radio20">
						<label for="op20" class="mr-1">Irradiado</label>
						<input type="radio" id="op20" class="dolorInfo" name="tipoDolor">
					</div>
				</div>
			</div>
		</div>
		<br>
		<div class="row text-left resaltar">
			<div class="col-md-4">
				<label class="labelCheck5">¿Dónde?</label>
					<input type="text" name="dondeDolor" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
			</div>
			<div class="col-md-4">
				<label class="labelCheck5">¿Hacia dónde?</label>
				<input type="text" name="haciaDondeDolor" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
			</div>
			<div class="col-md-4">
				<label class="labelCheck5">¿Puede calmarlo con algo?</label>
				<input type="text" name="calmarDolor" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
			</div>
		</div>
		<br>
		<div class="row text-left resaltar">
			<div class="col-md-4">
				<input type="checkbox" class="" id="check6" onclick="deshabilitar(this.id)">
				<label class="labelCheck6">¿Sufrió algún golpe en los dientes?</label>
				<div class="form-inline">
					<div class="form-inline radio21">
						<label for="op21" class="mr-1">Si</label>
						<input type="radio" id="op21" name="golpeDientes">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio22">
						<label for="op22" class="mr-1">No</label>
						<input type="radio" id="op22" name="golpeDientes">
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<label class="labelCheck6">¿Cuándo?</label>
				<input type="text" name="cuandoGolpeDolor" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
			</div>
			<div class="col-md-4">
				<label for="labelCheck6">¿Cómo se produjo?</label>
				<input type="text" name="comoProdujoGolpe" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
			</div>
		</div>
		<br>
		<div class="row text-left resaltar">
			<div class="col-md-4">
				<input type="checkbox" class="" id="check7" onclick="deshabilitar(this.id)">
				<label class="labelCheck7">¿Se le fracturó algún diente?</label>
				<div class="form-inline">
					<div class="form-inline radio23">
						<label for="op23" class="mr-1">Si</label>
						<input type="radio" id="op23" name="fracturaDiente">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio24">
						<label for="op24" class="mr-1">No</label>
						<input type="radio" id="op24" name="fracturaDiente">
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<label class="labelCheck7">¿Cuál?</label>
				<input type="text" name="cualDienteFracturado" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
			</div>
			<div class="col-md-4">
				<label for="labelCheck7">¿Cómo se produjo?</label>
				<input type="text" name="comoProdujoFractura" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
			</div>
		</div>
		<br>
		<div class="row text-left resaltar">
			<div class="col-md-4">
				<input type="checkbox" id="check8" class="" onclick="deshabilitar(this.id)">
				<label class="labelCheck8">¿Tiene dificultad para hablar?</label>
				<input type="text" name="dificultadHablar" class="form-control" aria-label="Small" aria-describedby=inputGroup-sizing-sm>
			</div>
			<div class="col-md-2">
				<input type="checkbox" id="check9" class="" onclick="deshabilitar(this.id)">
				<label class="labelCheck9">¿Para masticar?</label>
				<input type="text" name="dificultadMasticar"class="form-control" aria-label="Small" aria-describedby=inputGroup-sizing-sm >
			</div>
			<div class="col-md-3">
				<input type="checkbox" class="" id="check10"  onclick="deshabilitar(this.id)">
				<label class="labelCheck10">¿Para abrir la boca?</label>
				<input type="text" name="dificultadAbrirBoca" class="form-control" aria-label="Small" aria-describedby=inputGroup-sizing-sm>
			</div>
			<div class="col-md-3">
				<input type="checkbox" id="check11" class="" onclick="deshabilitar(this.id)">
				<label class="labelCheck11">¿Para tragar alimentos?</label>
				<input type="text" name="dificultadTragar" class="form-control" aria-label="Small" aria-describedby=inputGroup-sizing-sm>
			</div>
		</div>
		<br>
		<div class="row text-left resaltar">
			<div class="col-md-5">
				<input type="checkbox" class="" id="check12" onclick="deshabilitar(this.id)">
				<label class="labelCheck12">¿Ha observado algo anormal en los labios?</label>
				<input type="text" name="anormalLabios" class="form-control" aria-label="Small" aria-describedby=inputGroup-sizing-sm>
			</div>
			<div class="col-md-3">
				<input type="checkbox" class="" id="check13" onclick="deshabilitar(this.id)">
				<label class="labelCheck13">¿Lengua?</label>
				<input type="text" name="anormalLengua" class="form-control" aria-label="Small" aria-describedby=inputGroup-sizing-sm>
			</div>
			<div class="col-md-3">
				<input type="checkbox" class="" id="check14" onclick="deshabilitar(this.id)">
				<label class="labelCheck14">¿Paladar?</label>
				<input type="text" name="anormalPaladar" class="form-control" aria-label="Small" aria-describedby=inputGroup-sizing-sm>
			</div>
		</div>
		<br>
		<div class="row text-left resaltar">
			<div class="col-md-4">
				<input type="checkbox" id="check15" class="" onclick="deshabilitar(this.id)">
				<label class="labelCheck15">¿Piso de boca?</label>
				<input type="text" name="anormalPisoBoca" class="form-control" aria-label="Small" aria-describedby=inputGroup-sizing-sm>
			</div>
			<div class="col-md-4">
				<input type="checkbox" id="check16" class="" onclick="deshabilitar(this.id)">
				<label class="labelCheck16">¿Carrillos?</label>
				<input type="text" name="anormalCarrillos" class="form-control" aria-label="Small" aria-describedby=inputGroup-sizing-sm>
			</div>
			<div class="col-md-4">
				<input type="checkbox" class="" id="check17" onclick="deshabilitar(this.id)">
				<label class="labelCheck17">¿Rebordes?</label>
				<input type="text" name="anormalRebordes" class="form-control" aria-label="Small" aria-describedby=inputGroup-sizing-sm>
			</div>
		</div>
		<br>
		<div class="row text-left resaltar">
			<div class="col-md-5">
				<input type="checkbox" class="" id="check18" onclick="deshabilitar(this.id)">
				<label class="labelCheck18">¿Trígono?</label>
				<input type="text" name="anormalTrigono" class="form-control" aria-label="Small" aria-describedby=inputGroup-sizing-sm>
			</div>
			<div class="col-md-5">
				<input type="checkbox" class="" id="check19" onclick="deshabilitar(this.id)">
				<label class="labelCheck19">¿Retremolar?</label>
				<input type="text" name="anormalRetremolar" class="form-control" aria-label="Small" aria-describedby=inputGroup-sizing-sm>
			</div>
		</div>
		<br>
		<div class="row text-left resaltar">
			<div class="col-md-12">
			<input type="checkbox" id="check20" onclick="deshabilitar(this.id)">
			<label class="labelCheck20">¿Qué tipo de lesiones presenta?:</label>
			</div>
		</div>
		<br>
		<div class="row text-left resaltar">
			<div class="col-md-2">
				<label class="labelCheck20">¿Manchas?</label>
				<div class="form-inline">
					<div class="form-inline radio25">
						<label for="op25" class="mr-1">Si</label>
						<input type="radio" id="op25" name="lesionMancha">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio26">
						<label for="op26" class="mr-1">No</label>
						<input type="radio" id="op26" name="lesionMancha">
					</div>
				</div>
			</div>
			<div class="col-md-2">
				<label class="labelCheck20">¿Ulceraciones?</label>
				<div class="form-inline">
					<div class="form-inline radio27">
						<label for="op27" class="mr-1">Si</label>
						<input type="radio" id="op27" name="lesionUlcera">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio28">
						<label for="op28" class="mr-1">No</label>
						<input type="radio" id="op28" name="lesionUlcera">
					</div>
				</div>
			</div>
			<div class="col-md-2">
				<label class="labelCheck20">¿Ampollas?</label>
				<div class="form-inline">
					<div class="form-inline radio29">
						<label for="op29" class="mr-1">Si</label>
						<input type="radio" id="op29" name="lesionAmpolla">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio30">
						<label for="op30" class="mr-1">No</label>
						<input type="radio" id="op30" name="lesionAmpolla">
					</div>
				</div>
			</div>
			<div class="col-md-3">
				<label class="labelCheck20">¿Abultamiento de los tejidos?</label>
				<div class="form-inline">
					<div class="form-inline radio31">
						<label for="op31" class="mr-1">Si</label>
						<input type="radio" id="op31" name="lesionTejidos">
					</div>
					<div class="form-inline radio32">
						<label for="32" class="mr-1">No</label>
						<input type="radio" id="op32" name="lesionTejidos">
					</div>
				</div>
			</div>
		</div>
		<br>
		<div class="row text-left resaltar">
			<div class="col-md-8">
				<label class="labelCheck20">Otros</label>
				<input type="text" name="lesionOtros" class="form-control" aria-label="Small" aria-describedby=inputGroup-sizing-sm>
			</div>
		</div>
		<br>
		<div class="row text-left resaltar">
			<div class="col-md-3">
				<input type="checkbox" id="check21" class="" onclick="deshabilitar(this.id)">
				<label class="labelCheck21">¿Le sangran las encias?</label>
				<div class="form-inline">
					<div class="form-inline radio33">
						<label for="op33" class="mr-1">Si</label>
						<input type="radio" id="op33" name="sangraEncias">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio34">
						<label for="op34" class="mr-1">No</label>
						<input type="radio" id="op34" name="sangraEncias">
					</div>
				</div>
			</div>
			<div class="col-md-3">
				<label class="labelCheck21">¿Cuándo?</label>
				<input type="text" name="cuandoSangranE" class="form-control" aria-label="Small" aria-describedby=inputGroup-sizing-sm>
			</div>
			<div class="col-md-4">
				<input type="checkbox" id="check22"  class="" onclick="deshabilitar(this.id)">
				<label class="labelCheck22">¿Sale pus de algún lugar de su boca?</label>
				<div class="form-inline">
					<div class="form-inline radio35">
						<label for="op35" class="mr-1">Si</label>
						<input type="radio" id="op35" name="pus">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio36">
						<label for="op36" class="mr-1">No</label>
						<input type="radio" id="op36" name="pus">
					</div>
				</div>
			</div>
			<div class="col-md-2">
				<label class="labelCheck22">¿De donde?</label>
				<input type="text" name="dondePus" class="form-control" aria-label="Small" aria-describedby=inputGroup-sizing-sm>
			</div>
		</div>
		<br>
		<div class="row text-left resaltar">
			<div class="col-md-5">
				<input type="checkbox" class="" id="check23" onclick="deshabilitar(this.id)">
				<label class="labelCheck23">¿Tiene movilidad en sus dientes?</label>
					<div class="form-inline">
						<div class="form-inline radio37">
							<label for="op37" class="mr-1">Si</label>
							<input type="radio" id="op37" name="movilidad">
						</div>
						<div class="mr-2"></div>
						<div class="form-inline radio38">
							<label class="op38" class="mr-1">No</label>
							<input type="radio" id="op38" name="movilidad">
						</div>
					</div>
			</div>
			<div class="col-md-5">
				<input type="checkbox" id="check24" class="" onclick="deshabilitar(this.id)">
				<label class="labelCheck24">¿Al morder siente altos los dientes?</label>
				<input type="text" name="altosDientes" class="form-control" aria-label="Small" aria-describedby=inputGroup-sizing-sm>
			</div>
		</div>
		<br>
		<div class="row text-left resaltar">
			<div class="col-md-3">
				<input type="checkbox" id="check25" class="" onclick="deshabilitar(this.id)">
				<label class="labelCheck25">¿Ha tenido la cara hinchada?</label>
				<div class="form-inline">
					<div class="form-inline radio39">
						<label for="op39" class="mr-1">Si</label>
						<input type="radio" id="op39" name="caraHinchada">
					</div>
					<div class="form-inline radio40">
						<label for="op40" class="mr-1">No</label>
						<input type="radio" id="op40" name="caraHinchada">
					</div>
				</div>
			</div>
			<div class="col-md-3">
				<label class="labelCheck25">¿Se puso hielo?</label>
				<input type="text" name="pusoHielo" class="form-control" aria-label="Small" aria-describedby=inputGroup-sizing-sm>
			</div>
			<div class="col-md-3">
				<label class="labelCheck25">¿Calor?</label>
				<input type="input" name="calor"class="form-control" aria-label="Small" aria-describedby=inputGroup-sizing-sm>				
			</div>
			<div class="col-md-3">
				<label class="labelCheck25">¿Otros?</label>
				<input type="text" name="otrosHinchada"class="form-control" aria-label="Small" aria-describedby=inputGroup-sizing-sm>
			</div>
		</div>
		<br>
		<div class="row text-left resaltar">
			<div class="col-md-6">
				<input type="checkbox" class="" id="check26" onclick="deshabilitar(this.id)" >
				<label class="labelCheck26">Momento de azúcar diario</label>
				<input type="text" name="azucarDiario" class="form-control" aria-label="Small" aria-describedby=inputGroup-sizing-sm>
			</div>
			<div class="col-md-6">
				<input type="checkbox" class="" id="check27" onclick="deshabilitar(this.id)">
				<label class="labelCheck27">Indice de placa</label>
				<input type="text" name="indicePlaca" class="form-control" aria-label="Small" aria-describedby=inputGroup-sizing-sm>
			</div>
		</div>
		<br>
		<div class="row text-left resaltar">
			<div class="col-md-12">
				<input type="checkbox" id="check28" class="" onclick="deshabilitar(this.id)">
				<label class="labelCheck28">Estado de higiene bucal:</label>
			</div>
		</div>
		<div class="row text-left resaltar">
			<div class="col-md-12">
				<div class="form-inline">
					<div class="form-inline radio41">
						<label for="op41" class="mr-1">Muy bueno</label>
						<input type="radio" id="op41" name="estadoBucal">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio42">
						<label for="op42" class="mr-1">Bueno</label>
						<input type="radio" id="op42" name="estadoBucal">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio43">
						<label for="op43" class="mr-1">Deficiente</label>
						<input type="radio" id="op43" name="estadoBucal">
					</div>
					<div class="mr-2"></div>
					<div class="form-inline radio44">
						<label for="op44" class="mr-1">Malo</label>
						<input type="radio" id="op44" name="estadoBucal">
					</div>
				</div>
			</div>
		</div>
	</form>	
	<br>
		<div class="text-right">
			<button type="submit"  class="btn btn-lg btn-primary" >Guardar</button>
	
		</div>


<!-- </body> -->

<script src="/sistema/jquery-3.4.1.min.js">	</script>
<script type="text/javascript">
$(document).ready(function(){
	$('#hcOdontologica').click("input[id^=op]", function(){
			$("#op")	
		})
	})	
</script>
<script src="/sistema/bootstrap-4.4.1-dist/js/bootstrap.bundle.js"></script> 
</html>