<?php


$sql = "SELECT*FROM embarazo";
$rs_embarazo = mysqli_query($conexion, $sql);

$sql = "SELECT*FROM obrasocial";
$rs_obrasocial = mysqli_query($conexion, $sql);

$sql = "SELECT * FROM provincia ";
$rs_provincia = mysqli_query($conexion, $sql);

$sql = "SELECT * FROM ciudades";
$rs_ciudad = mysqli_query($conexion, $sql);


$sql = "SELECT estado 
FROM per_estado " .
	"WHERE id_per_estado=1 ";


?>


<!-- <!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Agregar Paciente</title> -->
<script type="text/javascript" src="../../funciones/consultarCombos.js"></script>
<link rel="stylesheet" type="text/css" href="/sistema/css/font.css">
<!-- <link rel="stylesheet" type="text/css" href="/sistema/bootstrap-4.4.1-dist/css/bootstrap.min.css"> -->


<!-- </head> -->
<!-- <body> -->
<form id="datosPersonales" method="POST" accept-charset="utf-8">
	<div class="row text-left resaltar">
		<div class="col-md-6">
			Nombre
			<input type="text" id="nombre" name="nombre" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
		</div>
		<div class="col-md-6">
			Apellido
			<input type="text" id="apellido" name="apellido" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
		</div>
	</div>
	<br>
	<div class="row text-left resaltar">
		<div class="col-md-2">
			D.N.I
			<input type="text" id="dni" name="dni" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
		</div>
		<div class="col-md-5">
			Fecha de nacimiento
			<input type="date" id="nacimiento" name="nacimiento" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
		</div>
		<div class="col-md-5">
			Fecha de ingreso
			<input type="date" id="ingreso" name="ingreso" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
		</div>
	</div>
	<br>
	<div class="row text-align resaltar">
		<div class="col-md-4">
			Género
			<div class="text-align">
				<input type="radio" name="genero" id="generoM">Masculino
				<input type="radio" name="genero" id="generoF">Femenino
			</div>
		</div>
		<div class="col-md-4" id="pregDiv">
			<label class="embarazo">¿Está embarazada?</label>
			<div class="form-inline">
				<div class="form-inline">
					<label class="mr-1" for="embarazoSi">Si</label>
					<input type="radio" class="embarazo" id="embarazoSi" name="embarazada">
				</div>
				<div class="mr-2"></div>
				<div class="form-inline">
					<label class="mr-1" for="embarazoNo">No</label>
					<input type="radio" class="embarazo" id="embarazoNo" name="embarazada">
				</div>
			</div>
		</div>
		<div class="col-md-4" id="pregMDiv">
			<label class="embarazo">¿De cuántos meses?</label>
			<select name="embarazoSelect" id="mesesSelect" class="custom-select">
				<option class="embarazo" value="sinEspecificar">Sin especificar</option>
				<?php while ($row = $rs_embarazo->fetch_assoc()) : ?>
					<option> value="<?php echo $row['id_embarazo']; ?>">
						<?php echo $row["meses"]; ?>
					</option>
				<?php endwhile; ?>
			</select>
		</div>
	</div>
	</div>
	<br>
	<div class="row text-left resaltar">
		<div class="col-md-4">
			Ocupación
			<input type="text" id="ocupacion" name="ocupacion" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
		</div>
		<div class="col-md-4" id="divObraSocial">
			Obra social
			<select name="obraSocial" id="obraSocial" class="custom-select">
				<option value="">Sin especificar</option>
				<?php while ($row = $rs_obrasocial->fetch_assoc()) : ?>
					<option value="<?php echo $row['id_obrasocial']; ?>">
						<?php echo $row["descripcion"]; ?>
					</option>
				<?php endwhile; ?>
			</select>
		</div>
		<div id="div_afiliado" class="col-md-4">
			<label id="Afiliado">N° Afiliado </label>
			<input id="afiliado" type="text" name="afiliado" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
		</div>
	</div>
	<br>
	<div class="row text-align resaltar">
		<div class="col-md-12">
			Observación
			<textarea id="observacion" class="form-control" aria-label="With textarea"></textarea>
		</div>
	</div>
	<br>
	<hr>
	<strong>Datos de contacto</strong>
	<div class="row text-left resaltar">
		<div class="col-md-4">
			Celular
			<input type="text" id="celular" name="celular" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
		</div>
		<div class="col-md-4">
			Teléfono fijo
			<input type="text" id="fijo" name="fijo" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
		</div>
		<div class="col-md-4">
			Correo electrónico
			<input type="email" id="correo" name="correo" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
		</div>
	</div>
	<br>
	<hr>
	<strong>Datos de domicilio</strong>
	<div class="row text-left resaltar">
		<div class="col-md-6">
			Provincia
			<select class="custom-select" name="cboProvincia" id="inputGroupSelect02" onchange="consultarCiudades(this.value)">
				<option value="">Sin especificar</option>
				<?php while ($datosProvincia = mysqli_fetch_array($rs_provincia)) { ?>
					<option id="provincia"> value= "<?php echo $datosProvincia['id_provincia'] ?>"> <?php echo $datosProvincia['descripcion']; ?> </option>
				<?php } ?>
			</select>
		</div>
		<div class="col-md-6">
			Ciudad
			<select class="custom-select" name="cboCiudad" id="inputGroupSelect02" onchange="consultarCiudades(this.value)">
				<option value="">Sin especificar</option>
				<?php while ($datosCiudad = mysqli_fetch_array($rs_ciudad)) { ?>
					<option id="ciudad"> value= "<?php echo $datosCiudad['id_ciudad'] ?>"> <?php echo $datosCiudad['descripcion']; ?> </option>
				<?php } ?>
			</select>
			</select>
		</div>
	</div>
	<br>
	<div class="row text-left resaltar">
		<div class=" col-md-4">
			Barrio:
			<select class="custom-select" id="barrio">
				<option selected>Choose...</option>
				<option value="1">One</option>
				<option value="2">Two</option>
				<option value="3">Three</option>
			</select>
		</div>
		<div class=" col-md-4">
			Calle:
			<select class="custom-select" id="calle">
				<option selected>Choose...</option>
				<option value="1">One</option>
				<option value="2">Two</option>
				<option value="3">Three</option>
			</select>
		</div>
		<div class="col-md-4">
			Altura:
			<input id="altura" type="text" name="altura" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
		</div>
	</div>
	<br>
	<div class="row text-align resaltar">
		<div class="col-md-3">
			Piso:
			<input id="piso" type="text" name="piso" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
		</div>
		<div class="col-md-3">
			Torre:
			<input id="torre" type="text" name="piso" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
		</div>
		<div class="col-md-3">
			Manzana:
			<input id="manzana" type="text" name="manzana" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
		</div>
		<div class="col-md-3">
			Sector/Parcela:
			<input id="sector" type="text" name="sectorp" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
		</div>
	</div>
	<br>
	<div class="row text-align resaltar">
		<div class="col-md-12">
			Observación:
			<textarea id="observacionDom" class="form-control" aria-label="With textarea"></textarea>
		</div>
	</div>
	<br>
	<div class="text-right">
		<button type="submit" class="btn btn-lg btn-primary">Guardar</button>

	</div>
	</div>
</form>

</html>