<?php 
require '../../php/conexion.php';


$nombre=$_POST['nombre'];
$apellido=$_POST['apellido'];
$dni=$_POST['dni'];
$nacimiento=date($_POST['nacimiento']);
$fechaingreso=date($_POST['fechaingreso']);
$embarazo=$_POST['embarazo'];
$mesesSelect=$_POST['mesesSelect'];
$obraSocial=$_POST['obraSocial'];
$afiliado=$_POST['afiliado'];
$observacionPer=$_POST['observacion'];
$celular=$_POST['celular'];
$fijo=$_POST['fijo'];
$correo=$_POST['correo'];
$provincia=$_POST['provincia'];
$ciudad=$_POST['ciudad'];
$barrio=$_POST['barrio'];
$calle=$_POST['calle'];
$altura=$_POST['altura'];
$piso=$_POST['piso'];
$manzana=$_POST['manzana'];
$sector=$_POST['sector'];
$observacionDom=$_POST['observacionDom'];
$genero=$_POST['genero'];
$ocupacion=$_POST['ocupacion'];

$id_per_estado=1;


$sql_personas="INSERT INTO personas (nombre,apellido,DNI,fechanacimiento, id_per_estado)".
"VALUES ('$nombre','$apellido','$dni', $nacimiento, $id_estado)";
mysqli_query($conexion,$sql_personas);
$id_persona = mysqli_insert_id($conexion);

echo $sql_personas;
exit();

$sql_genero= "INSERT INTO genero (genero) VALUES ($genero) ";
mysqli_query($conexion,$sql_genero);
$id_genero = mysqli_insert_id($conexion);


$sql_obraSocial= "INSERT INTO obraSocial(descripcion, nroafiliado) VALUES ('$obraSocial', '$afiliado')";
mysqli_query($conexion,$sql_obraSocial);
$id_obraSocial = mysqli_insert_id($conexion);


$sql_paciente="INSERT INTO pacientes (id_persona,fechaingreso,id_obrasocial,id_per_estado,id_genero,ocupacion, observacion) 
VALUES ($id_persona,$fechaingreso,$id_obrasocial,$id_per_estado,$id_genero,'$ocupacion')";
mysqli_query($conexion,$sql_paciente);
$id_paciente = mysqli_insert_id($conexion);

$sql_embarazo="INSERT INTO embarazo(esta_embarazada,id_paciente, meses) VALUES ($embarazo, $id_paciente, $mesesSelect) ";
mysqli_query($conexion,$sql_embarazo);

$sql_provincia="INSERT INTO provincia(nombre_prov) VALUES('$provincia')";
mysqli_query($conexion, $sql_provincia);
$id_provincia=mysqli_insert_id($conexion);

$sql_ciudad="INSERT INTO ciudades (descripcion, id_provincia)
VALUES ('$ciudad', $id_provincia) ";
mysqli_query($conexion, $sql);
$id_ciudad=mysqli_insert_id($conexion);

$sql_domicilio="INSERT INTO domicilios (id_persona, observacion, barrio, calle
altura, piso, torre, manzana, sector_parcela, id_ciudad) 
VALUES ($id_persona, '$observacionDom', '$barrio', $altura, $piso, $torre, $manzana, $sector
$id_ciudad)";



?>