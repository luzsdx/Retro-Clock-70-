// $(document).ready(function () {
// 	$("#datosPersonales").validate({
// 		rules: {
// 			nombre: {
// 				required: true,
// 				rangelength: [3, 20]
// 			},
// 			apellido: {
// 				required: true,
// 				rangelength: [3, 20]
// 			},
// 			dni: {
// 				required: true,
// 				rangelength: [6, 10]
// 			},
// 			nacimiento: {
// 				required: true,
// 			},
// 			ingreso: {
// 				required: true,
// 			},
// 			genero: {
// 				required: true
// 			}
// 		},
// 		messages: {
// 			nombre: {
// 				required: "Ingresar nombre del paciente",
// 				rangelength: "El nombre debe contener 3 a 20 caracteres"
// 			},
// 			apellido: {
// 				required: "Ingresar apellido del paciente",
// 				rangelength: "El apellido debe contener 3 a 20 caracteres"
// 			},
// 			dni: {
// 				required: "Ingresar DNI del paciente",
// 				rangelength: "El DNI debe contener 6 a 10 caracteres"
// 			},
// 			nacimiento: {
// 				required: "Seleccionar fecha de nacimiento del paciente"
// 			},
// 			ingreso: {
// 				required: "Seleccionar fecha de ingreso del paciente",
// 			},
// 			genero: {
// 				required: "Seleccione el género del paciente"
// 			}
// 		}
// 	})
// })