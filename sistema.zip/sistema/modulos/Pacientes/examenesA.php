<!-- <!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
	<link rel="stylesheet" type="text/css" href="/sistema/bootstrap-4.4.1-dist/css/bootstrap.min.css">

</head>
<body> -->
	<!-- <form id="examenes" method="POST" enctype="" >
	 <input type="file" name="imagen[]" id="examen" multiple accept=".jpg, .png, .gif" enctype="multipart/form-data">
	 <button type="submit">Subir</button>
	</form>
	<div id="examenesLista"> -->
		
	</div>
<!-- </body> -->
<!-- <script type="text/javascript">
	$(document).ready(function(){
		load_images();

		function load_images(){
			$.ajax({
			url:"fetch_imagenes.php",
			success:function(data){
				$('#examenesLista').html(data);
			}
		})
		}

		$('#examenes').on('submit', function(event){
			event.preventDefault();
			var examen_nombre=$('#examen').val()
			$.ajax({
				url:"inserExamA.php",
				method:"POST",
				data: new FormData(this),
				contentType:false,
				cache:false,
				processData:false,
				success:function(data){
					$('#image').val('');
					load_images();
				}
			})
		})
	})
</script> -->
