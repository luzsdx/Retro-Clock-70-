<?php

require '../../php/conexion.php';

session_start();

// Si no existe la variable de sesión logueado, entonces el usuario debe loguearse.
if (!isset($_SESSION["logueado"])) {
	header("location: ../../iniciar_sesion.php?error=debe_loguearse");
	exit;
}

if (isset($_GET['mensaje'])) {
	switch ($_GET['mensaje']) {
        case 'GUARDAR_PACIENTE_OK':
            $mensaje = 'Paciente agregado correctamente.';
            break;

		case 'GUARDAR_PACIENTE_ERROR':
			$mensaje = 'Ha ocurrido un error al intentar crear el Paciente.';
			break;

		case 'GUARDAR_PERSONA_ERROR':
			$mensaje = 'Ha ocurrido un error al intentar crear la persona.';
			break;
	}
}



$sql = "SELECT personas.`id_persona`, nombre, apellido, pacientes.`fechaingreso`, obrasocial.`descripcion`, nroafiliado, pac_estado.`estado` "
. " FROM pacientes"
." INNER JOIN personas ON pacientes.`id_persona`=personas.`id_persona` "
. "INNER JOIN obrasocial ON pacientes.`id_obrasocial`=obrasocial.`id_obrasocial`"
." INNER JOIN pac_estado ON pacientes.`id_pac_estado`=pac_estado.`id_pac_estado` "
. "WHERE pac_estado.estado=2";

$rs = mysqli_query($conexion,$sql);

$registros=mysqli_num_rows($rs);

?>



<!DOCTYPE html>
<html>
<head>
	<title>Pacientes dados de baja</title>
</head>
<body bgcolor="orange">
	<?php require '../../php/menu.php'; ?>
	<div align='center'>
		<h1><b>Pacientes dados de baja</b></h1>

    	<?php if (isset($mensaje)): ?>
    		<h3><font color="red"><?php echo $mensaje; ?></font></h3>
    	<?php endif; ?>

    	<p><a href="altaPaciente.php">Agregar</a>||<a href="buscar.php">Buscar</a></p>
		<p><a href="../../dashboard.php">Volver al menú</a>||<a href="listado.php">Pacientes activos</a></p>
		<br>
		<table border="1" cellpadding="2" cellspacing="0">
			<thead>
				<?php
					if ($registros==0) {
						echo "No existen pacientes dados de baja áun.";
					}else{ ?>
				<tr>
					<th>ID</th>
					<th>Nombre</th>
					<th>Apellido</th>
					<th>DNI</th>
					<th>Fecha de nacimiento</th>
					<th>Fecha Ingreso</th>
					<th>Obra social</th>
					<th>Acciones</th>
				</tr>
				<?php }
				 ?>
			</thead>
			<tbody>
				<?php 
				//if ($registros==0) {
				//		echo "Aún no existen pacientes dados de baja.";
				//}else{
					while ($row = $rs->fetch_assoc()): ?>
					<tr>
						<td> <?php echo utf8_encode($row['id_paciente']); ?> </td>
						<td> <?php echo utf8_encode($row['nombre']); ?> </td>
						<td> <?php echo utf8_encode($row['apellido']); ?> </td>
						<td> <?php echo utf8_encode($row['DNI']); ?> </td>
						<td> <?php echo utf8_encode($row['fechanacimiento']); ?> </td>
						<td> <?php echo utf8_encode($row['fechaingreso']); ?> </td>				
						<td> <?php echo utf8_encode($row['nro_afiliado']); ?> </td>
						<td> <?php echo utf8_encode($row['obrasocial']); ?> </td>
						<td><a href="../contacto/listado.php?id_persona=<?php echo $row['id_persona'];?>">Ver</a> </td>
						<td><a href="../domicilio/listado.php?id_persona=<?php echo $row['id_persona']; ?>">Ver</a></td>

						<td><a href="editar.php?id_persona=<?php echo $row['id_persona']; ?>">
							    Editar
							</a> | 
							<a href="procesamiento/procesarBaja.php?id_persona=<?php echo $row['id_persona']; ?>" onclick="return confirm('¿Estas seguro de que deseas eliminar el paciente?' )">
							    Eliminar
							</a>
						</td>
					</tr>
				<?php endwhile; ?>
			</tbody>
		</table>
	</div>
</body>
</html>