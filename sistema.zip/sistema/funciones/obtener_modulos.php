<?php

require_once '../php/conexion.php';

function obtener_modulos($persona_id) {
	// Es necesario esto ya que sino no es posible acceder a la conexión.
	// En este caso se convierte la variable conexion a una variable global.
	global $conexion;

	// Array vacío. Aquí agregaremos los módulos obtenidos.
	$modulos = [];

	// Consulta sql para obtener id y descrición dé los módulos.
	$sql	= "SELECT modulos.`id_modulo`,modulos.`descripcion`,modulos.`directorio` "
			."FROM usuarios JOIN perfiles ON usuarios.`id_perfil` = perfiles.`id` "
			." INNER JOIN perfilesxmodulos ON perfilesxmodulos.`id_perfil` = perfiles.`id` "
			." INNER JOIN modulos ON modulos.`id_modulo` = perfilesxmodulos.`id_modulo` "
			."WHERE usuarios.`id_persona` = ".$persona_id;

	


	$rs_modulos = mysqli_query($conexion, $sql);

	// Reccorro los registros y asigno los módulos al array.
	while ($datos = mysqli_fetch_array($rs_modulos)) {
		//$modulos[$row["id"]] = $row["descripcion"];
		$arreglo = ['id' => $datos['id_modulo'],
					'descripcion' => $datos['descripcion'],
					'directorio' => $datos['directorio']];
		$modulos[] = $arreglo;
	}

	// retorno los módulos obtenidos.
	return $modulos;
}

?>