<?php

require 'conexion.php';
require '../funciones/obtener_modulos.php';

// Obtenemos los datos enviados por el formulario
$usuario = $_POST['txtUsuario'];
$password = $_POST['txtPassword'];

// Consultamos en la tabla Usuarios para ver si existe
$sql = "SELECT id_persona FROM usuarios "
     . "WHERE username='$usuario' AND password='$password'";


$rs_usuario = mysqli_query($conexion, $sql);

// Obtengo la cantidad de registros devueltos por la consulta
$cantidad = mysqli_num_rows($rs_usuario);

// Si la cantidad es 0 (cero), entonces no existe usuario.
// Redirijo al formulario de login, con una variable error por metodo GET.
if ($cantidad == 0) {
	header('location: ../iniciar_sesion.php?error=login_error');
	exit;
}

// En caso de que cantidad sea mayor a 0 (cero), entonces hay que seguir validando
// Obtenemos el id_persona del usuario, de la consulta anterior.
$user = $rs_usuario->fetch_assoc();

// Consultamos por el estado del usuario: 1 = activo y 0 = inactivo
$sql = "SELECT apellido, nombre FROM personas "
     . "WHERE id_persona=" . $user['id_persona'];

$rs_persona = mysqli_query($conexion, $sql);
$persona = $rs_persona->fetch_assoc();

// Si el estado de la persona es = 1, entonces hago el login
// Si el estado de la persona es = 0, entonces persona inactiva
/*if ($persona['estado'] == 0) {
	// Redirijo al formulario de login, con una variable error por metodo GET.
	header('location: ../iniciar_sesion.php?error=usuario_inactivo');
	exit;
}
*/
// Si el usuario esta activo, entonces hay que crear sesión
session_start();
$_SESSION['logueado'] = true;
$_SESSION['usuario'] = $persona['nombre'] . ', ' . $persona['apellido'];
$_SESSION['id_persona'] = $user['id_persona'];

// Llamada a la función para obtener módulos.
// Esta función develve un array con el id y descripción de los módulos.
$modulos = obtener_modulos($user['id_persona']);

// Este array de módulos lo asigno a una variable de sesión.
$_SESSION["modulos"] = $modulos;

// Luego de crear la sesión debemos redireccionar
header('location: ../dashboard.php');

?>