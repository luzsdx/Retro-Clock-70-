
<?php

if (isset($_GET['error'])) {
	switch ($_GET['error']) {
        case 'debe_loguearse':
            $mensaje = 'Debe iniciar sesión.';
            break;

		case 'login_error':
			$mensaje = 'Usuario o Password incorrecto.';
			break;
		
		case 'usuario_inactivo':
			$mensaje = 'Usuario inactivo. Consulte con el administrador.';
			break;
	}
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Inicia Sesión</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=PT+Sans&display=swap" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="css/loginout.css">
    <link rel="stylesheet" type="text/css" href="css/cuenta.css">

</head>
<body class="cuerpo">
        <?php if (isset($mensaje)): ?>
            <h3><?php echo $mensaje; ?></h3>
        <?php endif; ?>

                <div class="container ">
                     <div class="row justify-content-center formulario ">
                 <div class="col-md4 shadow-lg rounded-lg bg-white p-3 m-5 ">
                    
                    <div class="form-group text-center linea">
                        <h1 class="text-center">Iniciar Sesión</h1>
                    </div>
                    <form id="Login" method="POST" action="php/procesar_login.php">
                    <div class=" form-group mx-sm-4">
                        <input id="txt" class="casilla bg-white" type="text" name="txtUsuario" placeholder="Ingrese su usuario" onkeyup="success()">
                    </div>

                     <div class=" form-group mx-sm-4">
                        <input id="txt" class="casilla bg-white" type="password" name="txtPassword" placeholder="Ingrese su contraseña" onkeyup="success()">
                    </div>

                     <div  class=" form-group mx-sm-4">
                    <button id="boton" class="login" type="submit" disabled>Ingresar</button>
                    ¿No te has registrado aún? Registrate <a href="registrarse.php" title="">aquí</a>

                    </div>
                </form>
                </div>
                
            </div>
            
        </div>

<script type="text/javascript">
function success() {
     if(document.getElementById("txt").value==="") { 
            document.getElementById('boton').disabled = true; 
        } else { 
            document.getElementById('boton').disabled = false;
        }
    } 


</script>              

<script src="jquery-3.4.1.min.js">
    $(document).ready(function(){
    $('#Login').validate({
            rules:{
        usuario:{
            required:true,
            minlength:3
        },
        contraseña: {
            required:true,
            minlength:5
        },
    },
    messages:{
        usuario: {
            required: "Por favor, ingrese su usuario",
            minlength: "Su usuario debe tener al menos 3 caracteres"
            },
        nombre: {
            required: "Por favor, ingrese su nombre",
            minlength: "Su nombre debe tener al menos 5 caracteres"
        }    
    }
    })
});
</script>

<script src="bootstrap-4.4.1-dist/js/bootstrap.bundle.js"></script> 


</body>
</html>

