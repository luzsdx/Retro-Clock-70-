<!DOCTYPE >
<html>
<head>
	<title>Inicio</title>
</head>
<body>

	<?php require 'php/dist/menu.php'; ?>

	<a href="php/cerrar_sesion.php">Cerrar sesion</a>	

</body>
</html>